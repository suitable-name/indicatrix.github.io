use crate::models::terminal::Terminal;
use crate::ui::terminal_view::TerminalView;
use anyhow::{Context, Result};
use async_lock::Mutex;
use async_tungstenite::tungstenite::protocol::Message;
use colored::Colorize;
use futures_lite::io::{AsyncWriteExt, BufReader};
use futures_lite::prelude::*;
use serde_json::json;
#[cfg(unix)]
use signal_hook::{
    consts::{SIGINT, SIGQUIT, SIGTERM},
    iterator::Signals,
};
use std::sync::Arc;
use url::Url;

/// A cloneable write handle to a live terminal websocket.
///
/// Send raw JSON strings (the full `["stdin", …]` payload) over this channel
/// and they will be forwarded to the websocket.  The channel is unbounded so
/// sends from the Slint event loop never block.
pub type TerminalWriteHandle = smol::channel::Sender<String>;

/// Handles execution of commands via websockets to a Jupyter terminal
pub struct TerminalExecutor {
    url: String,
    token: String,
    terminal: Terminal,
    terminal_view: Option<TerminalView>,
}

impl TerminalExecutor {
    /// Creates a new `TerminalExecutor`
    #[must_use]
    pub fn new(jupyter_url: &str, token: &str, terminal: Terminal) -> Self {
        Self {
            url: jupyter_url.to_string(),
            token: token.to_string(),
            terminal,
            terminal_view: None,
        }
    }

    /// Creates a new `TerminalExecutor` with UI output
    #[must_use]
    pub fn new_with_ui(
        jupyter_url: &str,
        token: &str,
        terminal: Terminal,
        terminal_view: TerminalView,
    ) -> Self {
        Self {
            url: jupyter_url.to_string(),
            token: token.to_string(),
            terminal,
            terminal_view: Some(terminal_view),
        }
    }

    /// Connect once to the terminal websocket and spawn reader/writer tasks
    /// (via `slint::spawn_local`) so the connection persists for the lifetime
    /// of the UI window.
    ///
    /// Incoming `stdout`/`stderr` chunks are appended to `terminal_view`.
    /// Returns a [`TerminalWriteHandle`] the caller reuses for every command
    /// and special-key send.  `is_executing` is set `true` while connecting
    /// and reset to `false` once the reader is running (terminal is
    /// interactive, not request/response).
    ///
    /// # Errors
    /// Returns an error if the websocket URL is invalid, the connection fails,
    /// or a Slint task cannot be spawned.
    pub async fn connect_persistent(
        jupyter_url: &str,
        token: &str,
        terminal: Terminal,
        terminal_view: TerminalView,
    ) -> Result<TerminalWriteHandle> {
        let ws_url = format!(
            "{}/terminals/websocket/{}?token={}",
            jupyter_url, terminal.name, token
        );
        let url = Url::parse(&ws_url).context("Failed to parse terminal WebSocket URL")?;

        let (ws_stream, _) = async_tungstenite::smol::connect_async(url.as_str())
            .await
            .context("Failed to connect to terminal WebSocket")?;

        let (write, mut read) = ws_stream.split();

        // Channel: callers send serialised JSON strings; writer task forwards
        // them to the websocket.
        let (tx, rx) = smol::channel::unbounded::<String>();

        let write_mutex = Arc::new(Mutex::new(write));
        let write_for_writer = Arc::clone(&write_mutex);
        let view_for_reader = terminal_view.clone();

        // Writer task
        slint::spawn_local(async move {
            while let Ok(payload) = rx.recv().await {
                let mut w = write_for_writer.lock().await;
                if let Err(e) = w.send(Message::Text(payload.into())).await {
                    eprintln!("Terminal websocket send error: {e}");
                    break;
                }
            }
        })
        .map_err(|e| anyhow::anyhow!("Failed to spawn terminal writer: {e}"))?;

        // Reader task
        slint::spawn_local(async move {
            let _write = write_mutex; // keep write half alive

            // Connection is live – clear the "connecting" executing flag so
            // the Send button re-enables.
            let _ = view_for_reader.set_executing(false);

            while let Some(message) = futures_lite::StreamExt::next(&mut read).await {
                match message {
                    Ok(Message::Text(text)) => {
                        if let Ok(received) = serde_json::from_str::<Vec<String>>(&text) {
                            if received.len() >= 2 {
                                let msg_type = &received[0];
                                let content = &received[1];

                                // Jupyter terminal multiplexes via BEL (0x07)
                                let parts: Vec<&str> = content.split('\u{7}').collect();
                                for part in parts {
                                    if msg_type == "stdout" {
                                        print!("{part}");
                                        let _ = view_for_reader.append_output(part);
                                    } else if msg_type == "stderr" {
                                        eprint!("{part}");
                                        let _ = view_for_reader
                                            .append_output(&format!("Error: {part}"));
                                    } else {
                                        let _ = view_for_reader.append_output(&format!(
                                            "Unknown message type '{msg_type}': {part}"
                                        ));
                                    }
                                }
                            }
                        }
                    }
                    Ok(
                        Message::Binary(_)
                        | Message::Ping(_)
                        | Message::Pong(_)
                        | Message::Frame(_),
                    ) => {}
                    Ok(Message::Close(_)) => {
                        println!("{}", "Terminal WebSocket closed".yellow().bold());
                        let _ = view_for_reader
                            .append_output("\nWebSocket connection closed\n");
                        let _ = view_for_reader.set_executing(false);
                        break;
                    }
                    Err(e) => {
                        eprintln!("{} {}", "Terminal WebSocket error:".red().bold(), e);
                        let _ = view_for_reader
                            .append_output(&format!("\nWebSocket error: {e}\n"));
                        let _ = view_for_reader.set_executing(false);
                        break;
                    }
                }
            }
        })
        .map_err(|e| anyhow::anyhow!("Failed to spawn terminal reader: {e}"))?;

        Ok(tx)
    }

    /// Send a command (with trailing `\r`) on an existing write handle.
    ///
    /// # Errors
    /// Returns an error if serialisation fails or the channel is closed.
    pub fn send_command_on_handle(handle: &TerminalWriteHandle, command: &str) -> Result<()> {
        let payload = json!(["stdin", format!("{command}\r")]);
        let json = serde_json::to_string(&payload)?;
        handle
            .try_send(json)
            .map_err(|e| anyhow::anyhow!("Terminal write handle closed: {e}"))?;
        Ok(())
    }

    /// Send a raw control sequence (no trailing `\r`) on an existing write
    /// handle.  Used for Ctrl+C / Ctrl+D / Ctrl+\\.
    ///
    /// # Errors
    /// Returns an error if serialisation fails or the channel is closed.
    pub fn send_special_key_on_handle(
        handle: &TerminalWriteHandle,
        raw_bytes: &str,
    ) -> Result<()> {
        let payload = json!(["stdin", raw_bytes]);
        let json = serde_json::to_string(&payload)?;
        handle
            .try_send(json)
            .map_err(|e| anyhow::anyhow!("Terminal write handle closed: {e}"))?;
        Ok(())
    }

    /// Send a terminal command via the websocket (used by `execute`)
    async fn send_command<S>(
        &self,
        command: &str,
        write: &mut async_tungstenite::WebSocketSender<S>,
    ) -> Result<()>
    where
        S: futures::AsyncRead + futures::AsyncWrite + Unpin,
    {
        let command_with_cr = format!("{command}\r");
        let payload = json!(["stdin", command_with_cr]);
        let json_payload = serde_json::to_string(&payload)?;
        write.send(Message::Text(json_payload.into())).await?;
        Ok(())
    }

    /// Execute commands in the terminal (CLI / non-UI path).
    ///
    /// # Errors
    /// Returns an error if connection or communication fails.
    ///
    /// # Panics
    /// May panic if signal handling setup fails.
    #[allow(clippy::too_many_lines)]
    pub async fn execute(&self, initial_command: Option<String>) -> Result<()> {
        let ws_url = format!(
            "{}/terminals/websocket/{}?token={}",
            self.url, self.terminal.name, self.token
        );

        let url = Url::parse(&ws_url).context("Failed to parse WebSocket URL")?;
        let (ws_stream, _) = async_tungstenite::smol::connect_async(url.as_str())
            .await
            .context("Failed to connect to WebSocket")?;
        let (mut write, mut read) = ws_stream.split();

        if let Some(terminal_view) = &self.terminal_view {
            terminal_view.set_executing(true)?;
        }

        if let Some(cmd) = &initial_command {
            if !cmd.is_empty() {
                println!("{} {}", "Executing initial command:".blue().bold(), cmd);
                if let Some(terminal_view) = &self.terminal_view {
                    terminal_view.append_output(&format!("Executing: {cmd}\n"))?;
                }
                self.send_command(cmd, &mut write).await?;
            }
        }

        let write_mutex = Arc::new(Mutex::new(write));
        #[cfg(unix)]
        let write_for_signals = Arc::clone(&write_mutex);
        let terminal = self.terminal.clone();

        #[cfg(unix)]
        {
            let terminal_clone = terminal.clone();
            let write_for_sigint = Arc::clone(&write_for_signals);

            if self.terminal_view.is_none() {
                smol::spawn(async move {
                    let mut signals = Signals::new([SIGINT, SIGTERM, SIGQUIT])
                        .expect("Failed to create signal handler");

                    while let Some(signal) = signals.forever().next() {
                        let key = match signal {
                            SIGINT => "\x03",
                            SIGTERM => "\x04",
                            SIGQUIT => "\x1C",
                            _ => continue,
                        };

                        let mut write = write_for_sigint.lock().await;
                        let _ = send_key(&terminal_clone, key, &mut *write).await;
                    }
                })
                .detach();
            }
        }

        let write_for_input = Arc::clone(&write_mutex);
        let terminal_clone = terminal.clone();

        if self.terminal_view.is_none() {
            let initial_command_clone = initial_command.clone();
            smol::spawn(async move {
                if let Some(cmd) = initial_command_clone {
                    if !cmd.is_empty() {
                        println!("{} {}", "Executing initial command:".blue().bold(), cmd);
                        let mut write = write_for_input.lock().await;
                        let _ = send_key(&terminal_clone, &cmd, &mut *write).await;
                    }
                }

                let reader = BufReader::new(smol::Unblock::new(std::io::stdin()));
                let mut lines = reader.lines();

                while let Some(line) = futures_lite::StreamExt::next(&mut lines).await {
                    if let Ok(line) = line {
                        if line == "exit" {
                            println!("{}", "Exiting program.".red().bold());
                            std::process::exit(0);
                        } else if line.starts_with("init") {
                            let commands = [
                                "cd /tmp &&",
                                "wget https://github.com/oobabooga/text-generation-webui/releases/download/installers/oobabooga_linux.zip &&",
                                "unzip oobabooga_linux.zip &&",
                                "cd oobabooga_linux &&",
                                "chmod +x ./start_linux.sh",
                            ];

                            let mut write = write_for_input.lock().await;
                            let _ =
                                send_key(&terminal_clone, &commands.join(" "), &mut *write).await;
                        } else {
                            let mut write = write_for_input.lock().await;
                            let _ = send_key(&terminal_clone, &line, &mut *write).await;
                        }
                    }
                }
            })
            .detach();
        }

        while let Some(message) = futures_lite::StreamExt::next(&mut read).await {
            match message {
                Ok(Message::Text(text)) => {
                    if let Ok(received) = serde_json::from_str::<Vec<String>>(&text) {
                        if received.len() >= 2 {
                            let msg_type = &received[0];
                            let content = &received[1];

                            let content_parts: Vec<&str> = content.split('\u{7}').collect();
                            for part in content_parts {
                                if msg_type == "stdout" {
                                    print!("{part}");
                                    if let Some(terminal_view) = &self.terminal_view {
                                        terminal_view.append_output(part)?;
                                    }
                                    let mut stdout = smol::Unblock::new(std::io::stdout());
                                    stdout.flush().await.unwrap_or_default();
                                } else if msg_type == "stderr" {
                                    eprintln!("{} {}", "Error:".red().bold(), part);
                                    if let Some(terminal_view) = &self.terminal_view {
                                        terminal_view
                                            .append_output(&format!("Error: {part}"))?;
                                    }
                                } else {
                                    println!(
                                        "{} {}: {}",
                                        format!("Unknown message type '{msg_type}'")
                                            .yellow()
                                            .bold(),
                                        msg_type,
                                        part
                                    );
                                    if let Some(terminal_view) = &self.terminal_view {
                                        terminal_view.append_output(&format!(
                                            "Unknown message type '{msg_type}': {part}"
                                        ))?;
                                    }
                                }
                            }
                        }
                    }
                }
                Ok(Message::Binary(_) | Message::Ping(_) | Message::Pong(_) | Message::Frame(_)) => {}
                Ok(Message::Close(_)) => {
                    println!("{}", "WebSocket connection closed".yellow().bold());
                    if let Some(terminal_view) = &self.terminal_view {
                        terminal_view.append_output("\nWebSocket connection closed\n")?;
                        terminal_view.set_executing(false)?;
                    }
                    break;
                }
                Err(e) => {
                    eprintln!("{} {}", "WebSocket error:".red().bold(), e);
                    if let Some(terminal_view) = &self.terminal_view {
                        terminal_view.append_output(&format!("\nWebSocket error: {e}\n"))?;
                        terminal_view.set_executing(false)?;
                    }
                    break;
                }
            }
        }

        Ok(())
    }
}

// Helper function to send keys to the terminal (CLI path)
async fn send_key<S>(
    _terminal: &Terminal,
    key: &str,
    write: &mut async_tungstenite::WebSocketSender<S>,
) -> Result<()>
where
    S: futures::AsyncRead + futures::AsyncWrite + Unpin,
{
    let command = format!("{key}\r");
    let payload = json!(["stdin", command]);
    let json_payload = serde_json::to_string(&payload)?;
    write.send(Message::Text(json_payload.into())).await?;
    Ok(())
}
