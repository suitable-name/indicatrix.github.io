use crate::models::kernel::{message_types, ExecuteRequest, WebSocketMessage};
use crate::ui::code_editor::CodeEditor;
use anyhow::Result;
use async_lock::Mutex;
use async_tungstenite::tungstenite::protocol::Message;
use colored::Colorize;
use futures_lite::io::BufReader;
use futures_lite::prelude::*;
use std::sync::Arc;
use syntect::{
    easy::HighlightLines,
    highlighting::ThemeSet,
    parsing::SyntaxSet,
    util::{as_24_bit_terminal_escaped, LinesWithEndings},
};

/// A cloneable write handle to an open kernel-channels websocket.
///
/// Internally backed by a channel so callers never touch the raw socket type.
pub type KernelWriteHandle = smol::channel::Sender<String>;

/// Handles execution of code via websockets to a Jupyter kernel
pub struct CodeExecutor {
    url: String,
    token: String,
    kernel_id: String,
    session_id: String,
    code_editor: Option<CodeEditor>,
}

impl CodeExecutor {
    /// Creates a new `CodeExecutor`
    #[must_use]
    pub fn new(jupyter_url: &str, token: &str, kernel_id: &str, session_id: &str) -> Self {
        Self {
            url: jupyter_url.to_string(),
            token: token.to_string(),
            kernel_id: kernel_id.to_string(),
            session_id: session_id.to_string(),
            code_editor: None,
        }
    }

    /// Creates a new `CodeExecutor` with UI output
    #[must_use]
    pub fn new_with_ui(
        jupyter_url: &str,
        token: &str,
        kernel_id: &str,
        session_id: &str,
        code_editor: CodeEditor,
    ) -> Self {
        Self {
            url: jupyter_url.to_string(),
            token: token.to_string(),
            kernel_id: kernel_id.to_string(),
            session_id: session_id.to_string(),
            code_editor: Some(code_editor),
        }
    }

    /// Highlight Python code with syntax highlighting
    ///
    /// # Errors
    /// Returns an error if highlighting fails.
    pub fn highlight_code(code: &str) -> Result<String> {
        let ps = SyntaxSet::load_defaults_newlines();
        let ts = ThemeSet::load_defaults();

        let syntax = ps
            .find_syntax_by_extension("py")
            .ok_or_else(|| anyhow::anyhow!("Failed to find python syntax"))?;
        let mut h = HighlightLines::new(syntax, &ts.themes["base16-ocean.dark"]);

        let mut output = String::new();
        for line in LinesWithEndings::from(code) {
            let ranges = h.highlight_line(line, &ps)?;
            let escaped = as_24_bit_terminal_escaped(&ranges[..], true);
            output.push_str(&escaped);
        }

        Ok(output)
    }

    /// Connect once to the kernel channels websocket and spawn a reader task
    /// (via `slint::spawn_local`) that routes incoming messages to
    /// `code_editor`.
    ///
    /// Returns a [`KernelWriteHandle`] (an `smol::channel::Sender<String>`)
    /// that the caller can keep and use for every subsequent
    /// `ExecuteRequest` — call [`Self::send_execute_request`] with it.
    ///
    /// # Errors
    /// Returns an error if the websocket connection cannot be established or
    /// if the Slint reader task cannot be spawned.
    pub async fn connect_persistent(
        jupyter_url: &str,
        token: &str,
        kernel_id: &str,
        code_editor: CodeEditor,
    ) -> Result<KernelWriteHandle> {
        let ws_url = format!(
            "{jupyter_url}/api/kernels/{kernel_id}/channels?token={token}"
        );

        let (ws_stream, _) = async_tungstenite::smol::connect_async(ws_url.as_str()).await?;
        let (write, mut read) = ws_stream.split();

        // Channel: callers send serialised JSON strings; the writer task
        // forwards them to the websocket.
        let (tx, rx) = smol::channel::unbounded::<String>();

        let write_mutex = Arc::new(Mutex::new(write));
        let write_for_writer = Arc::clone(&write_mutex);
        let editor_for_reader = code_editor.clone();

        // Writer task: receives JSON strings from the channel, sends them on
        // the websocket.
        slint::spawn_local(async move {
            while let Ok(json) = rx.recv().await {
                let mut w = write_for_writer.lock().await;
                if let Err(e) = w.send(Message::Text(json.into())).await {
                    eprintln!("Kernel websocket send error: {e}");
                    break;
                }
            }
        })
        .map_err(|e| anyhow::anyhow!("Failed to spawn kernel writer: {e}"))?;

        // Reader task: receives messages from the websocket, routes to UI.
        slint::spawn_local(async move {
            // Keep write_mutex alive so the writer task's Arc doesn't drop
            // the write half while the reader is still going.
            let _write = write_mutex;

            while let Some(message) = futures_lite::StreamExt::next(&mut read).await {
                match message {
                    Ok(Message::Text(text)) => {
                        if let Ok(msg) = serde_json::from_str::<WebSocketMessage>(&text) {
                            if let Err(e) =
                                handle_kernel_message(&msg, &editor_for_reader)
                            {
                                eprintln!("Error handling kernel message: {e}");
                            }
                        }
                    }
                    Ok(
                        Message::Binary(_)
                        | Message::Ping(_)
                        | Message::Pong(_)
                        | Message::Frame(_),
                    ) => {}
                    Ok(Message::Close(_)) => {
                        println!("{}", "Kernel WebSocket closed".yellow().bold());
                        let _ = editor_for_reader
                            .append_output("\nWebSocket connection closed\n");
                        let _ = editor_for_reader.set_executing(false);
                        break;
                    }
                    Err(e) => {
                        eprintln!("{} {}", "Kernel WebSocket error:".red().bold(), e);
                        let _ = editor_for_reader
                            .append_output(&format!("\nWebSocket error: {e}\n"));
                        let _ = editor_for_reader.set_executing(false);
                        break;
                    }
                }
            }
        })
        .map_err(|e| anyhow::anyhow!("Failed to spawn kernel reader: {e}"))?;

        Ok(tx)
    }

    /// Send an `execute_request` on an already-open [`KernelWriteHandle`].
    ///
    /// # Errors
    /// Returns an error if serialisation fails or the write handle is closed.
    pub fn send_execute_request(
        write_handle: &KernelWriteHandle,
        code: &str,
        session_id: &str,
    ) -> Result<()> {
        let execute_request = ExecuteRequest::new(code, session_id);
        let json = serde_json::to_string(&execute_request)?;
        write_handle
            .try_send(json)
            .map_err(|e| anyhow::anyhow!("Kernel write handle closed: {e}"))?;
        Ok(())
    }

    /// Send code to execute via the websocket (used internally by `execute`)
    async fn send_code<S>(
        &self,
        code: &str,
        ws_stream: &mut async_tungstenite::WebSocketSender<S>,
    ) -> Result<()>
    where
        S: futures::AsyncRead + futures::AsyncWrite + Unpin,
    {
        if let Ok(highlighted) = Self::highlight_code(code) {
            println!("{highlighted}");
            if let Some(code_editor) = &self.code_editor {
                code_editor.append_output(&format!("\n{highlighted}\n"))?;
            }
        } else {
            println!("{code}");
            if let Some(code_editor) = &self.code_editor {
                code_editor.append_output(&format!("\n{code}\n"))?;
            }
        }

        let execute_request = ExecuteRequest::new(code, &self.session_id);
        let json = serde_json::to_string(&execute_request)?;
        ws_stream.send(Message::Text(json.into())).await?;
        Ok(())
    }

    /// Execute code and handle the interactive session (CLI / non-UI path).
    ///
    /// # Errors
    /// Returns an error if connection or communication fails.
    #[allow(clippy::too_many_lines)]
    pub async fn execute(&self, initial_code: Option<String>) -> Result<()> {
        let ws_url = format!(
            "{}/api/kernels/{}/channels?token={}",
            self.url, self.kernel_id, self.token
        );

        let (ws_stream, _) = async_tungstenite::smol::connect_async(ws_url.as_str()).await?;

        let (mut write, mut read) = ws_stream.split();

        if let Some(code_editor) = &self.code_editor {
            code_editor.set_executing(true)?;
        }

        if let Some(code) = initial_code {
            if code.is_empty() {
                println!("\n{}", "python3>".green().bold());
                if let Some(code_editor) = &self.code_editor {
                    code_editor.append_output("\npython3> ")?;
                }
            } else {
                println!("{}", "Executing initial code:".blue().bold());
                self.send_code(&code, &mut write).await?;
            }
        } else {
            println!("\n{}", "python3>".green().bold());
            if let Some(code_editor) = &self.code_editor {
                code_editor.append_output("\npython3> ")?;
            }
        }

        let write_handle = Arc::new(Mutex::new(write));
        let session_id = self.session_id.clone();

        if self.code_editor.is_none() {
            smol::spawn(async move {
                let reader = BufReader::new(smol::Unblock::new(std::io::stdin()));
                let mut lines = reader.lines();

                while let Some(line) = futures_lite::StreamExt::next(&mut lines).await {
                    if let Ok(line) = line {
                        if line == "exit" {
                            println!("{}", "Exiting program.".red().bold());
                            std::process::exit(0);
                        }
                        if line.starts_with("load ") {
                            let filename = line.trim_start_matches("load ").trim().to_string();
                            match smol::fs::read_to_string(filename).await {
                                Ok(content) => {
                                    println!(
                                        "{} {}",
                                        "Executing code from file".blue().bold(),
                                        line.trim_start_matches("load ").trim()
                                    );
                                    let req = ExecuteRequest::new(&content, &session_id);
                                    if let Ok(json) = serde_json::to_string(&req) {
                                        let mut w = write_handle.lock().await;
                                        if let Err(e) =
                                            w.send(Message::Text(json.into())).await
                                        {
                                            eprintln!("Error sending message: {e}");
                                        }
                                    }
                                }
                                Err(e) => {
                                    eprintln!("{} {}", "Error reading file:".red().bold(), e);
                                }
                            }
                        } else if line.starts_with("install ") {
                            let tool = line.trim_start_matches("install ").trim();
                            let command = format!("!apt-get install -y {tool}");
                            println!("{} {}", "Installing".blue().bold(), tool);
                            let req = ExecuteRequest::new(&command, &session_id);
                            if let Ok(json) = serde_json::to_string(&req) {
                                let mut w = write_handle.lock().await;
                                if let Err(e) = w.send(Message::Text(json.into())).await {
                                    eprintln!("Error sending message: {e}");
                                }
                            }
                        } else {
                            println!("{}", "Executing code".blue().bold());
                            let req = ExecuteRequest::new(&line, &session_id);
                            if let Ok(json) = serde_json::to_string(&req) {
                                let mut w = write_handle.lock().await;
                                if let Err(e) = w.send(Message::Text(json.into())).await {
                                    eprintln!("Error sending message: {e}");
                                }
                            }
                        }
                    }
                }
            })
            .detach();
        }

        while let Some(message) = futures_lite::StreamExt::next(&mut read).await {
            match message {
                Ok(Message::Text(text)) => {
                    if let Ok(msg) = serde_json::from_str::<WebSocketMessage>(&text) {
                        match msg.msg_type() {
                            message_types::STREAM => {
                                if let Some(content) = msg.content {
                                    if let Some(text_val) = content.get("text") {
                                        println!("\n{text_val}\n");
                                        if let Some(code_editor) = &self.code_editor {
                                            code_editor.append_output(&format!("\n{text_val}\n"))?;
                                        }
                                    }
                                }
                            }
                            message_types::EXECUTE_RESULT => {
                                if let Some(content) = msg.content {
                                    if let Some(data) = content.get("data") {
                                        println!("{} {}", "Result:".blue().bold(), data);
                                        if let Some(code_editor) = &self.code_editor {
                                            code_editor
                                                .append_output(&format!("\nResult: {data}\n"))?;
                                        }
                                    }
                                }
                            }
                            message_types::EXECUTE_REPLY => {
                                println!("{}", "Code execution completed".blue().bold());
                                if let Some(code_editor) = &self.code_editor {
                                    code_editor.append_output("\nCode execution completed\n")?;
                                    code_editor.append_output("\npython3> ")?;
                                    code_editor.set_executing(false)?;
                                }
                                println!("\n{}", "python3>".green().bold());
                            }
                            message_types::ERROR => {
                                if let Some(content) = msg.content {
                                    let ename = content
                                        .get("ename")
                                        .and_then(serde_json::Value::as_str)
                                        .unwrap_or("Error");
                                    let evalue = content
                                        .get("evalue")
                                        .and_then(serde_json::Value::as_str)
                                        .unwrap_or("");
                                    let traceback = content
                                        .get("traceback")
                                        .and_then(serde_json::Value::as_array)
                                        .map(|arr| {
                                            arr.iter()
                                                .filter_map(serde_json::Value::as_str)
                                                .collect::<Vec<_>>()
                                                .join("\n")
                                        })
                                        .unwrap_or_default();
                                    let rendered = format!("\n{ename}: {evalue}\n{traceback}\n");
                                    eprintln!("{}", rendered.red().bold());
                                    if let Some(code_editor) = &self.code_editor {
                                        code_editor.append_output(&rendered)?;
                                        code_editor.set_executing(false)?;
                                    }
                                }
                            }
                            _ => {}
                        }
                    }
                }
                Ok(Message::Binary(_) | Message::Ping(_) | Message::Pong(_) | Message::Frame(_)) => {}
                Ok(Message::Close(_)) => {
                    println!("{}", "WebSocket connection closed".yellow().bold());
                    if let Some(code_editor) = &self.code_editor {
                        code_editor.append_output("\nWebSocket connection closed\n")?;
                        code_editor.set_executing(false)?;
                    }
                    break;
                }
                Err(e) => {
                    eprintln!("{} {}", "WebSocket error:".red().bold(), e);
                    if let Some(code_editor) = &self.code_editor {
                        code_editor.append_output(&format!("\nWebSocket error: {e}\n"))?;
                        code_editor.set_executing(false)?;
                    }
                    break;
                }
            }
        }

        Ok(())
    }
}

/// Route a single decoded [`WebSocketMessage`] to the UI editor.
fn handle_kernel_message(msg: &WebSocketMessage, code_editor: &CodeEditor) -> Result<()> {
    match msg.msg_type() {
        message_types::STREAM => {
            if let Some(content) = &msg.content {
                if let Some(text) = content.get("text") {
                    println!("\n{text}\n");
                    code_editor.append_output(&format!("\n{text}\n"))?;
                }
            }
        }
        message_types::EXECUTE_RESULT => {
            if let Some(content) = &msg.content {
                if let Some(data) = content.get("data") {
                    println!("{} {}", "Result:".blue().bold(), data);
                    code_editor.append_output(&format!("\nResult: {data}\n"))?;
                }
            }
        }
        message_types::EXECUTE_REPLY => {
            println!("{}", "Code execution completed".blue().bold());
            code_editor.append_output("\nCode execution completed\n")?;
            code_editor.append_output("\npython3> ")?;
            code_editor.set_executing(false)?;
        }
        message_types::ERROR => {
            if let Some(content) = &msg.content {
                let ename = content
                    .get("ename")
                    .and_then(serde_json::Value::as_str)
                    .unwrap_or("Error");
                let evalue = content
                    .get("evalue")
                    .and_then(serde_json::Value::as_str)
                    .unwrap_or("");
                let traceback = content
                    .get("traceback")
                    .and_then(serde_json::Value::as_array)
                    .map(|arr| {
                        arr.iter()
                            .filter_map(serde_json::Value::as_str)
                            .collect::<Vec<_>>()
                            .join("\n")
                    })
                    .unwrap_or_default();
                let rendered = format!("\n{ename}: {evalue}\n{traceback}\n");
                eprintln!("{}", rendered.red().bold());
                code_editor.append_output(&rendered)?;
                code_editor.set_executing(false)?;
            }
        }
        _ => {}
    }
    Ok(())
}
