//! A Rust library for interacting with Paperspace API and Jupyter notebooks.

pub mod api;
pub mod jupyter;
pub mod models;
pub mod ui;
pub mod utils;
pub mod websocket;

// Re-export commonly used types for convenience
pub use api::{
    machine_types::get_available_machine_types,
    notebooks::{get_notebooks, start_notebook, wait_for_running_state},
};

pub use jupyter::{kernel::KernelManager, session::SessionManager, terminal::TerminalManager};

pub use websocket::{code_executor::CodeExecutor, terminal_executor::TerminalExecutor};

pub use models::{
    kernel::Kernel,
    notebook::{LabelAvailability, Notebook, NotebookListResponse},
    session::Session,
    terminal::Terminal,
};

// Utility functions
pub use utils::{
    cli::{choose_option, get_parsed_input, get_user_input},
    formatting::{highlight_python_code, print_machine_types, print_notebooks},
    signals::setup_signal_handlers,
};
