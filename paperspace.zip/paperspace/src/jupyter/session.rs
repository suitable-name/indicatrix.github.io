use crate::models::session::Session;
use anyhow::Result;
use serde_json::json;
use surf::Client;

/// Functions for managing Jupyter sessions
pub struct SessionManager {
    jupyter_url: String,
    token: String,
    client: Client,
}

impl SessionManager {
    /// Create a new session manager
    #[must_use]
    pub fn new(jupyter_url: &str, token: &str) -> Self {
        Self {
            jupyter_url: jupyter_url.to_string(),
            token: token.to_string(),
            client: surf::client(),
        }
    }

    /// Get all existing sessions
    /// 
    /// # Errors
    /// Returns an error if the request or parsing fails.
    pub async fn get_sessions(&self) -> Result<Vec<Session>> {
        let url = format!("{}/api/sessions?token={}", self.jupyter_url, self.token);

        let mut response = self.client.get(&url).await.map_err(|e| anyhow::anyhow!("Request failed: {e}"))?;
        let sessions: Vec<Session> = response.body_json().await.map_err(|e| anyhow::anyhow!("Parsing failed: {e}"))?;

        Ok(sessions)
    }

    /// Start a new session
    /// 
    /// # Errors
    /// Returns an error if the request or parsing fails.
    pub async fn start_session(&self) -> Result<Session> {
        let url = format!("{}/api/sessions?token={}", self.jupyter_url, self.token);

        let json_body = json!({
            "name": "python3",
            "path": "",
            "type": "notebook"
        });

        let mut response = self
            .client
            .post(&url)
            .body(surf::Body::from_json(&json_body).map_err(|e| anyhow::anyhow!("Body creation failed: {e}"))?)
            .await
            .map_err(|e| anyhow::anyhow!("Request failed: {e}"))?;

        let session: Session = response.body_json().await.map_err(|e| anyhow::anyhow!("Parsing failed: {e}"))?;

        Ok(session)
    }

    /// Get an existing session or start a new one
    /// 
    /// # Errors
    /// Returns an error if retrieving or starting a session fails.
    pub async fn resume_session(&self) -> Result<(Session, bool)> {
        // Get the list of existing sessions
        let sessions = self.get_sessions().await?;

        // If there is an existing session, return it and set isNewSession flag to false
        if let Some(session) = sessions.first() {
            return Ok((session.clone(), false));
        }

        // Otherwise, create a new session and set isNewSession flag to true
        let session = self.start_session().await?;
        Ok((session, true))
    }
}
