use crate::models::terminal::Terminal;
use anyhow::Result;
use surf::Client;

/// Functions for managing Jupyter terminals
pub struct TerminalManager {
    jupyter_url: String,
    token: String,
    client: Client,
}

impl TerminalManager {
    /// Create a new terminal manager
    #[must_use]
    pub fn new(jupyter_url: &str, token: &str) -> Self {
        Self {
            jupyter_url: jupyter_url.to_string(),
            token: token.to_string(),
            client: surf::client(),
        }
    }

    /// Get all existing terminals
    /// 
    /// # Errors
    /// Returns an error if the request or parsing fails.
    pub async fn get_terminals(&self) -> Result<Vec<Terminal>> {
        let url = format!("{}/api/terminals?token={}", self.jupyter_url, self.token);

        let mut response = self.client.get(&url).await.map_err(|e| anyhow::anyhow!("Request failed: {e}"))?;
        let terminals: Vec<Terminal> = response.body_json().await.map_err(|e| anyhow::anyhow!("Parsing failed: {e}"))?;

        Ok(terminals)
    }

    /// Create a new terminal
    /// 
    /// # Errors
    /// Returns an error if the request or parsing fails.
    pub async fn create_terminal(&self) -> Result<Terminal> {
        let url = format!("{}/api/terminals?token={}", self.jupyter_url, self.token);

        let mut response = self.client.post(&url).await.map_err(|e| anyhow::anyhow!("Request failed: {e}"))?;
        let terminal: Terminal = response.body_json().await.map_err(|e| anyhow::anyhow!("Parsing failed: {e}"))?;

        Ok(terminal)
    }

    /// Get an existing terminal or create a new one
    /// 
    /// # Errors
    /// Returns an error if retrieving or creating a terminal fails.
    pub async fn get_or_create_terminal(&self) -> Result<(Terminal, bool)> {
        let terminals = self.get_terminals().await?;

        if let Some(terminal) = terminals.first() {
            return Ok((terminal.clone(), false));
        }

        let terminal = self.create_terminal().await?;
        Ok((terminal, true))
    }
}
