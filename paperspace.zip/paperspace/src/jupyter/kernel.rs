use crate::models::kernel::Kernel;
use anyhow::Result;
use serde_json::json;
use surf::Client;

/// Functions for managing Jupyter kernels
pub struct KernelManager {
    jupyter_url: String,
    token: String,
    client: Client,
}

impl KernelManager {
    /// Create a new kernel manager
    #[must_use]
    pub fn new(jupyter_url: &str, token: &str) -> Self {
        Self {
            jupyter_url: jupyter_url.to_string(),
            token: token.to_string(),
            client: surf::client(),
        }
    }

    /// Get all running kernels
    /// 
    /// # Errors
    /// Returns an error if the request or parsing fails.
    pub async fn get_kernels(&self) -> Result<Vec<Kernel>> {
        let url = format!("{}/api/kernels?token={}", self.jupyter_url, self.token);

        let mut response = self.client.get(&url).await.map_err(|e| anyhow::anyhow!("Request failed: {e}"))?;
        let kernels: Vec<Kernel> = response.body_json().await.map_err(|e| anyhow::anyhow!("Parsing failed: {e}"))?;

        Ok(kernels)
    }

    /// Start a new kernel
    /// 
    /// # Errors
    /// Returns an error if the request or parsing fails.
    pub async fn start_kernel(&self) -> Result<String> {
        let url = format!("{}/api/kernels?token={}", self.jupyter_url, self.token);

        let json_body = json!({
            "name": "python3"
        });

        let mut response = self
            .client
            .post(&url)
            .body(surf::Body::from_json(&json_body).map_err(|e| anyhow::anyhow!("Body creation failed: {e}"))?)
            .await
            .map_err(|e| anyhow::anyhow!("Request failed: {e}"))?;

        let kernel: Kernel = response.body_json().await.map_err(|e| anyhow::anyhow!("Parsing failed: {e}"))?;

        Ok(kernel.id)
    }

    /// Get a running kernel or start a new one
    /// 
    /// # Errors
    /// Returns an error if retrieving or starting a kernel fails.
    pub async fn get_or_start_kernel(&self) -> Result<(Kernel, bool)> {
        let kernels = self.get_kernels().await?;

        if let Some(kernel) = kernels.first() {
            return Ok((kernel.clone(), false));
        }

        let kernel_id = self.start_kernel().await?;
        Ok((Kernel { id: kernel_id }, true))
    }
}
