use crate::models::notebook::{LabelAvailability, NotebookListResponse};
use anyhow::Result;
use colored::Colorize;
use std::io::{self, Write};
use syntect::easy::HighlightLines;
use syntect::highlighting::ThemeSet;
use syntect::parsing::SyntaxSet;
use syntect::util::{as_24_bit_terminal_escaped, LinesWithEndings};
use tabwriter::TabWriter;

/// Prints a list of notebooks in a formatted table
pub fn print_notebooks(notebooks: &NotebookListResponse) {
    let mut tw = TabWriter::new(io::stdout());

    // Write header
    if writeln!(
        tw,
        "\n{}",
        "ID\tClusterID\tProject\tHandle\tName\tState\tVmType"
            .cyan()
            .bold()
    ).is_err() {
        return;
    }

    // Write data rows
    for (i, notebook) in notebooks.notebook_list.iter().enumerate() {
        if writeln!(
            tw,
            "{}\t{}\t{}\t{}\t{}\t{}\t{}",
            (i + 1).to_string().blue(),
            notebook.cluster_id.blue(),
            notebook.project.blue(),
            notebook.handle.blue(),
            notebook.name.blue(),
            notebook.state.blue(),
            notebook.vm_type.blue()
        ).is_err() {
            break;
        }
    }

    // Flush to display
    let _ = tw.flush();
}

/// Prints a list of machine types with their availability
pub fn print_machine_types(labels: &[LabelAvailability]) {
    let mut tw = TabWriter::new(io::stdout());

    // Write header
    if writeln!(tw, "ID\tLabel\tAvailability").is_err() {
        return;
    }

    // Write data rows
    for (i, label) in labels.iter().enumerate() {
        let availability = if label.is_available {
            "Available".green()
        } else {
            "Unavailable".red()
        };

        if writeln!(tw, "{}\t{}\t{}", i + 1, label.label, availability).is_err() {
            break;
        }
    }

    // Flush to display
    let _ = tw.flush();
}

/// Prints notebook details in a formatted way
pub fn print_notebook_details(notebook: &crate::models::notebook::NotebookStartResponse) {
    println!("\n{}", "Notebook Details:".yellow());
    println!("{}: {}", "Project".cyan(), notebook.project);
    println!("{}: {}", "Handle".cyan(), notebook.handle);
    println!("{}: {}", "FQDN".cyan(), notebook.fqdn);
    println!("{}: {}", "Token".cyan(), notebook.token);
    println!(
        "{}: https://{}?token={}",
        "Notebook API".cyan(),
        notebook.fqdn,
        notebook.token
    );
}

/// Highlights Python code for display
/// 
/// # Errors
/// Returns an error if highlighting fails.
/// 
/// # Panics
/// Panics if the default syntax set cannot be loaded.
pub fn highlight_python_code(code: &str) -> Result<String> {
    let ps = SyntaxSet::load_defaults_newlines();
    let ts = ThemeSet::load_defaults();

    let syntax = ps.find_syntax_by_extension("py").ok_or_else(|| anyhow::anyhow!("Failed to find python syntax"))?;
    let mut h = HighlightLines::new(syntax, &ts.themes["base16-ocean.dark"]);

    let mut output = String::new();
    for line in LinesWithEndings::from(code) {
        let ranges = h.highlight_line(line, &ps)?;
        let escaped = as_24_bit_terminal_escaped(&ranges[..], true);
        output.push_str(&escaped);
    }

    Ok(output)
}

/// Formats a message as a Python prompt
#[must_use]
pub fn format_python_prompt() -> String {
    format!("\n{}", "python3>".green().bold())
}
