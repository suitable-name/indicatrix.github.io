#[cfg(unix)]
mod imp {
    use anyhow::Result;
    use signal_hook::consts::{SIGINT, SIGQUIT, SIGTERM};
    use signal_hook::iterator::Signals;

    /// Sets up signal handlers for `SIGINT`, `SIGQUIT`, and `SIGTERM`.
    ///
    /// Spawns a detached smol task that calls `callback` with the signal number
    /// each time one of the three signals arrives.
    ///
    /// # Errors
    /// Returns an error if the underlying `signal_hook` iterator cannot be
    /// created (e.g. the process has no permission to intercept the signal).
    pub async fn setup_signal_handlers<F>(mut callback: F) -> Result<()>
    where
        F: FnMut(i32) + Send + 'static,
    {
        let signals = Signals::new([SIGINT, SIGQUIT, SIGTERM])?;

        smol::spawn(async move {
            let mut signals = signals;
            for signal in signals.forever() {
                callback(signal);
            }
        })
        .detach();

        Ok(())
    }

    /// Maps a POSIX signal number to the terminal control-sequence byte(s) it
    /// represents.
    ///
    /// | Signal   | Sequence | Meaning  |
    /// |----------|----------|----------|
    /// | `SIGINT`  | `\x03`   | Ctrl+C   |
    /// | `SIGTERM` | `\x04`   | Ctrl+D   |
    /// | `SIGQUIT` | `\x1C`   | Ctrl+\\  |
    #[must_use]
    pub fn signal_to_key_code(signal: i32) -> Option<&'static str> {
        match signal {
            SIGINT => Some("\x03"),
            SIGTERM => Some("\x04"),
            SIGQUIT => Some("\x1C"),
            _ => None,
        }
    }
}

#[cfg(not(unix))]
mod imp {
    use anyhow::Result;

    // Standard POSIX signal numbers — used only for the key-code mapping on
    // non-Unix targets where signal_hook is unavailable.
    const SIGINT: i32 = 2;
    const SIGTERM: i32 = 15;
    const SIGQUIT: i32 = 3;

    /// Registers a Ctrl+C handler on Windows (and other non-Unix platforms).
    ///
    /// Uses the `ctrlc` crate, which wraps `SetConsoleCtrlHandler` on Windows.
    /// The callback receives `SIGINT` (2) to mirror the Unix behaviour.
    ///
    /// Only Ctrl+C is handled on non-Unix platforms; `SIGTERM` and `SIGQUIT`
    /// have no Windows equivalents.
    ///
    /// # Errors
    /// Returns an error if `ctrlc::set_handler` fails (e.g. a handler has
    /// already been registered, or the OS call fails).
    pub async fn setup_signal_handlers<F>(mut callback: F) -> Result<()>
    where
        F: FnMut(i32) + Send + 'static,
    {
        ctrlc::set_handler(move || callback(SIGINT))
            .map_err(|e| anyhow::anyhow!("Failed to set Ctrl+C handler: {e}"))?;
        Ok(())
    }

    /// Maps a signal number to the terminal control-sequence byte(s) it
    /// represents.
    ///
    /// | Signal   | Sequence | Meaning  |
    /// |----------|----------|----------|
    /// | `SIGINT`  | `\x03`   | Ctrl+C   |
    /// | `SIGTERM` | `\x04`   | Ctrl+D   |
    /// | `SIGQUIT` | `\x1C`   | Ctrl+\\  |
    #[must_use]
    pub fn signal_to_key_code(signal: i32) -> Option<&'static str> {
        match signal {
            SIGINT => Some("\x03"),
            SIGTERM => Some("\x04"),
            SIGQUIT => Some("\x1C"),
            _ => None,
        }
    }
}

pub use imp::{setup_signal_handlers, signal_to_key_code};
