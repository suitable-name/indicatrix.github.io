// utils/cli.rs
use anyhow::Result;
use colored::Colorize;
use futures_lite::io::BufReader;
use futures_lite::prelude::*;
use std::str::FromStr;

/// Reads user input with a prompt and returns it as a string
/// 
/// # Errors
/// Returns an error if reading from stdin fails.
pub async fn get_user_input(prompt: &str) -> Result<String> {
    print!("{prompt}");
    let mut stdout = smol::Unblock::new(std::io::stdout());
    stdout.flush().await?;

    let mut line = String::new();
    let stdin = smol::Unblock::new(std::io::stdin());
    BufReader::new(stdin).read_line(&mut line).await?;

    // Trim newlines and whitespace
    Ok(line.trim().to_string())
}

/// Reads user input with a prompt and parses it to the requested type
/// 
/// # Errors
/// Returns an error if reading or parsing fails.
pub async fn get_parsed_input<T>(prompt: &str) -> Result<T>
where
    T: FromStr,
    T::Err: std::fmt::Display,
{
    let input = get_user_input(prompt).await?;
    match input.parse::<T>() {
        Ok(value) => Ok(value),
        Err(e) => {
            eprintln!("{} {}", "Error parsing input:".red().bold(), e);
            Err(anyhow::anyhow!("Failed to parse input"))
        }
    }
}

/// Gets a selection from a numbered list
/// 
/// # Errors
/// Returns an error if reading input fails.
pub async fn get_selection<T>(prompt: &str, max: usize) -> Result<usize>
where
    T: FromStr,
    T::Err: std::fmt::Display,
{
    loop {
        let selection: usize = get_parsed_input(prompt).await?;
        if selection > 0 && selection <= max {
            return Ok(selection);
        }
        println!(
            "{}",
            format!("Please enter a number between 1 and {max}").yellow()
        );
    }
}

/// Asks the user to choose between multiple options
/// 
/// # Errors
/// Returns an error if reading input fails.
pub async fn choose_option<T: AsRef<str>>(prompt: &str, options: &[T]) -> Result<usize> {
    println!("{prompt}");

    for (i, option) in options.iter().enumerate() {
        println!("{}. {}", i + 1, option.as_ref());
    }

    get_selection::<usize>(
        &format!("Enter your choice (1-{}): ", options.len()),
        options.len(),
    )
    .await
}

/// Displays a yes/no prompt and returns true for yes, false for no
/// 
/// # Errors
/// Returns an error if reading input fails.
pub async fn yes_no_prompt(prompt: &str) -> Result<bool> {
    loop {
        let input = get_user_input(&format!("{prompt} (y/n): ")).await?;
        match input.to_lowercase().as_str() {
            "y" | "yes" => return Ok(true),
            "n" | "no" => return Ok(false),
            _ => println!("{}", "Please enter 'y' or 'n'.".yellow()),
        }
    }
}
