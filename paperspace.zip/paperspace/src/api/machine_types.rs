use crate::models::notebook::{LabelAvailability, MachineTypeResponse};
use anyhow::Result;
use colored::Colorize;
use indicatif::{ProgressBar, ProgressStyle};
use std::time::Duration;

/// Get available machine types from Paperspace API
/// 
/// # Errors
/// Returns an error if the request or parsing fails.
/// 
/// # Panics
/// Panics if the response body cannot be read.
pub async fn get_available_machine_types(
    token: &str,
) -> Result<Vec<LabelAvailability>, anyhow::Error> {
    let url = format!(
        "https://api.paperspace.io/vmTypes/getVmTypesByClusters?access_token={token}&namespace=tto8eel53n&includePublicClusters=true"
    );

    let mut response = surf::get(&url).await.map_err(|e| anyhow::anyhow!("Request failed: {e}"))?;

    if !response.status().is_success() {
        anyhow::bail!("Failed to get machine types: {}", response.status());
    }

    let data: MachineTypeResponse = response.body_json().await.unwrap();
    let labels = parse_machine_type_data(data);

    Ok(labels)
}

/// Parse machine type data from API response
fn parse_machine_type_data(
    data: MachineTypeResponse,
) -> Vec<LabelAvailability> {
    let mut labels = Vec::new();

    for (_, cluster_machines) in data.clusters {
        for machine in cluster_machines {
            if machine.vm_type.label.contains("Free") {
                labels.push(LabelAvailability {
                    label: machine.vm_type.label.clone(),
                    is_available: machine.is_available,
                    vm_type_id: machine.vm_type_id,
                });
            }
        }
    }

    // Remove duplicates if needed
    labels.sort_by(|a, b| a.label.cmp(&b.label));
    labels.dedup_by(|a, b| a.label == b.label);

    labels
}

/// Check if a machine type is available
#[must_use]
pub fn is_machine_type_available(machine_type: &str, labels: &[LabelAvailability]) -> bool {
    labels
        .iter()
        .any(|label| label.label == machine_type && label.is_available)
}

/// Wait for a machine type to become available
/// 
/// # Errors
/// Returns an error if retrieving machine types fails.
pub async fn check_availability(
    machine_type: &LabelAvailability,
    mut labels: Vec<LabelAvailability>,
    machine_type_token: &str,
) -> Result<()> {
    let mut is_available = is_machine_type_available(&machine_type.label, &labels);

    if is_available {
        return Ok(());
    }

    let bar = ProgressBar::new(10);
    let style = ProgressStyle::default_bar()
        .template(
            "{spinner:.green} [{elapsed_precise}] [{bar:40.cyan/blue}] {pos}/{len} ({eta})",
        )
        .map_err(|e| anyhow::anyhow!("Style error: {e}"))?
        .progress_chars("#>-");
    bar.set_style(style);

    while !is_available {
        bar.set_position(0);

        for i in 0..10 {
            bar.set_position(i + 1);
            smol::Timer::after(Duration::from_secs(1)).await;
        }

        labels = get_available_machine_types(machine_type_token).await?;
        is_available = is_machine_type_available(&machine_type.label, &labels);
    }

    bar.finish_with_message(
        format!("{} is now available!", machine_type.label)
            .green()
            .to_string(),
    );

    Ok(())
}
