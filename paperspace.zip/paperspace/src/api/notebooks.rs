use super::machine_types::check_availability;
use crate::api::client::{build_url, ApiClient};
use crate::models::notebook::{
    LabelAvailability, Notebook, NotebookListRequest, NotebookListResponse, NotebookStartRequest,
    NotebookStartResponse,
};
use anyhow::Result;
use colored::Colorize;
use log::info;
use std::{collections::HashMap, time::Duration};

/// Get the list of notebooks from Paperspace API
/// 
/// # Errors
/// Returns an error if the request or parsing fails.
pub async fn get_notebooks(token: &str) -> Result<NotebookListResponse> {
    let api_client = ApiClient::new();
    let api_url = "https://api.paperspace.io/notebooks/getNotebooks";

    let filters = NotebookListRequest::new();
    let filter_json = serde_json::to_string(&filters)?;

    let mut params = HashMap::new();
    params.insert("filter".to_string(), filter_json);
    params.insert("access_token".to_owned(), token.to_owned());
    params.insert("modelName".to_owned(), "team".to_owned());
    params.insert("clusterId".to_owned(), String::new());
    params.insert("namespace".to_owned(), "tto8eel53n".to_owned());

    let url = build_url(api_url, &params)?;
    info!("{url}");
    let response = api_client.get(&url).await.map_err(|e| anyhow::anyhow!("Request failed: {e}"))?;

    api_client.parse_json(response).await
}

/// Find a notebook by handle
#[must_use]
pub fn get_notebook_by_handle(
    notebooks: &NotebookListResponse,
    handle: &str,
) -> Option<Notebook> {
    notebooks
        .notebook_list
        .iter()
        .find(|n| n.handle == handle)
        .cloned()
}

/// Start a notebook with the specified machine type
/// 
/// # Errors
/// Returns an error if the notebook fails to start after retries.
pub async fn start_notebook(
    notebook: &Notebook,
    machine_type: &LabelAvailability,
    machine_type_token: &str,
) -> Result<NotebookStartResponse> {
    let api_client = ApiClient::new();

    // Get the initial list of available machine types
    let labels = super::machine_types::get_available_machine_types(machine_type_token).await?;

    if notebook.state == "Running" {
        println!("The notebook is already running.");

        // Return running notebook details as if a new one was started
        let running_notebooks = get_notebooks(machine_type_token).await?;
        if let Some(n) = running_notebooks.find_by_handle(&notebook.handle) {
            if let (Some(fqdn), Some(token)) = (n.fqdn.as_ref(), n.token.as_ref()) {
                return Ok(NotebookStartResponse {
                    project: n.project.clone(),
                    handle: n.handle.clone(),
                    state: n.state.clone(),
                    fqdn: fqdn.clone(),
                    token: token.clone(),
                });
            }
        }
    }

    // Wait for the machine type to become available
    check_availability(machine_type, labels, machine_type_token).await?;

    // Once the machine is available, proceed with starting the notebook
    let api_url = format!(
        "https://api.paperspace.io/notebooks/v2/startNotebook?access_token={machine_type_token}"
    );
    let request_body = NotebookStartRequest::new(notebook, machine_type);

    // Try up to 20 times
    for i in 0..20 {
        let req = api_client.post(&api_url, &request_body)?;
        let mut response = req.await.map_err(|e| anyhow::anyhow!("Request failed: {e}"))?;

        if response.status().is_success() {
            let notebook_resp: NotebookStartResponse = api_client.parse_json(response).await?;
            print_notebook_details(&notebook_resp);
            return Ok(notebook_resp);
        }
        
        if response.status() != 429 {
            // If the error is not a rate limit (429), break
            let body_str = response.body_string().await.map_err(|e| anyhow::anyhow!("Body error: {e}"))?;
            println!("Response: {body_str}");
            anyhow::bail!("Failed to start notebook: {}", response.status());
        }
        
        // If rate limited, wait and check availability again
        println!("{} Retrying {} of 20...", "Rate limited.".yellow(), i + 1);
        let labels =
            super::machine_types::get_available_machine_types(machine_type_token).await?;
        check_availability(machine_type, labels, machine_type_token).await?;
    }

    anyhow::bail!("Failed to start notebook after maximum retries")
}

/// Wait for a notebook to reach the running state
/// 
/// # Errors
/// Returns an error if retrieving the notebook list fails.
pub async fn wait_for_running_state(handle: &str, token: &str) -> Result<Notebook> {
    println!("{}", "Waiting for notebook to start...".cyan());

    loop {
        let notebook_list = get_notebooks(token).await?;
        if let Some(notebook) = notebook_list.find_by_handle(handle) {
            if notebook.state == "Running" {
                return Ok(notebook.clone());
            }
            println!("Notebook state: {}", notebook.state);
        } else {
            println!("Notebook not found");
        }

        smol::Timer::after(Duration::from_secs(10)).await;
    }
}

/// Print notebook details in a formatted way
fn print_notebook_details(notebook: &NotebookStartResponse) {
    println!("\n{}", "Notebook Details:".yellow());
    println!("{}: {}", "Project".cyan(), notebook.project);
    println!("{}: {}", "Handle".cyan(), notebook.handle);
    println!("{}: {}", "FQDN".cyan(), notebook.fqdn);
    println!("{}: {}", "Token".cyan(), notebook.token);
    println!(
        "{}: https://{}?token={}",
        "Notebook API".cyan(),
        notebook.fqdn,
        notebook.token
    );
}
