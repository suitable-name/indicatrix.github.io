use anyhow::{Context, Result};
use colored::Colorize;
use serde::Serialize;
use std::collections::HashMap;
use surf::{Body, Client as SurfClient, RequestBuilder, Response, Url};

/// API client for Paperspace API
pub struct ApiClient {
    client: SurfClient,
}

impl ApiClient {
    /// Create a new API client with the given token
    #[must_use]
    pub fn new() -> Self {
        Self {
            client: surf::client(),
        }
    }

    /// Create a GET request
    #[must_use]
    pub fn get(&self, url: &str) -> RequestBuilder {
        self.client.get(url)
    }

    /// Create a POST request with JSON body
    /// 
    /// # Errors
    /// Returns an error if serialization fails.
    pub fn post<T: Serialize + ?Sized>(&self, url: &str, body: &T) -> Result<RequestBuilder> {
        let json = serde_json::to_string(body)?;
        let mut req = self.client.post(url);
        req = req.header("Content-Type", "application/json");
        req = req.body(Body::from_string(json));
        Ok(req)
    }

    /// Create a POST request with URL-encoded form data
    #[must_use]
    pub fn post_form(&self, url: &str, params: &HashMap<String, String>) -> RequestBuilder {
        let query_string = params
            .iter()
            .map(|(k, v)| format!("{k}={v}"))
            .collect::<Vec<_>>()
            .join("&");

        let mut req = self.client.post(url);
        // req = req.header("x-api-key", &self.token);
        req = req.header("Content-Type", "application/x-www-form-urlencoded");
        req = req.body(Body::from_string(query_string));
        req
    }

    /// Parse JSON response
    /// 
    /// # Errors
    /// Returns an error if the request was not successful or parsing fails.
    pub async fn parse_json<T: serde::de::DeserializeOwned>(
        &self,
        mut response: Response,
    ) -> Result<T> {
        let status = response.status();
        let body = response.body_string().await.map_err(|e| anyhow::anyhow!("Failed to read body: {e}"))?;

        if !status.is_success() {
            eprintln!("{}: {} - {}", "API Error".red().bold(), status, body);
            anyhow::bail!("API request failed with status {status}: {body}");
        }

        serde_json::from_str(&body).with_context(|| format!("Failed to parse response: {body}"))
    }
}

impl Default for ApiClient {
    fn default() -> Self {
        Self::new()
    }
}

/// Build a URL with query parameters
/// 
/// # Errors
/// Returns an error if the base URL is invalid.
pub fn build_url<S: ::std::hash::BuildHasher>(base: &str, params: &HashMap<String, String, S>) -> Result<String> {
    let mut url = Url::parse(base)?;

    for (key, value) in params {
        url.query_pairs_mut().append_pair(key, value);
    }

    Ok(url.to_string())
}
