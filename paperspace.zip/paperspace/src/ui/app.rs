use crate::models::notebook::{LabelAvailability, Notebook, NotebookStartResponse};
use crate::ui::{MachineTypeItem, MainWindow, NotebookItem};
use anyhow::Result;
use slint::{ComponentHandle, ModelRc, SharedString, VecModel};
use std::time::Duration;

/// Main application window controller using Slint UI.
pub struct MainWindowController {
    window: slint::Weak<MainWindow>,
}

impl MainWindowController {
    /// Create a new main window controller.
    /// 
    /// # Errors
    /// Returns an error if the window cannot be created.
    pub fn new() -> Result<Self> {
        let window = MainWindow::new()?;
        Ok(Self {
            window: window.as_weak(),
        })
    }

    /// Get the underlying Slint window (weak pointer).
    #[must_use]
    pub fn window(&self) -> slint::Weak<MainWindow> {
        self.window.clone()
    }

    /// Run the UI event loop.
    /// 
    /// # Errors
    /// Returns an error if the event loop fails.
    pub fn run(&self) -> Result<()> {
        if let Some(window) = self.window.upgrade() {
            window.run()?;
        }
        Ok(())
    }

    /// Update the notebook list in the UI.
    /// 
    /// # Errors
    /// Returns an error if updating the UI fails.
    pub fn update_notebook_list(&self, notebooks: &[Notebook]) -> Result<()> {
        if let Some(window) = self.window.upgrade() {
            let mut notebook_data = Vec::new();
            for (i, notebook) in notebooks.iter().enumerate() {
                notebook_data.push(NotebookItem {
                    id: (i + 1).to_string().into(),
                    cluster_id: notebook.cluster_id.clone().into(),
                    project: notebook.project.clone().into(),
                    name: notebook.name.clone().into(),
                    handle: notebook.handle.clone().into(),
                    state: notebook.state.clone().into(),
                    vm_type: notebook.vm_type.clone().into(),
                });
            }
            window.set_notebooks(ModelRc::new(VecModel::from(notebook_data)));
        }
        Ok(())
    }

    /// Update the machine types list in the UI.
    /// 
    /// # Errors
    /// Returns an error if updating the UI fails.
    pub fn update_machine_types(&self, machine_types: &[LabelAvailability]) -> Result<()> {
        if let Some(window) = self.window.upgrade() {
            let mut machine_type_data = Vec::new();
            for (i, mt) in machine_types.iter().enumerate() {
                machine_type_data.push(MachineTypeItem {
                    id: (i + 1).to_string().into(),
                    label: mt.label.clone().into(),
                    available: mt.is_available,
                });
            }
            window.set_machine_types(ModelRc::new(VecModel::from(machine_type_data)));
        }
        Ok(())
    }

    /// Set the loading state in the UI.
    /// 
    /// # Errors
    /// Returns an error if updating the UI fails.
    pub fn set_loading(&self, loading: bool) -> Result<()> {
        if let Some(window) = self.window.upgrade() {
            window.set_loading(loading);
        }
        Ok(())
    }

    /// Set the status text in the UI.
    /// 
    /// # Errors
    /// Returns an error if updating the UI fails.
    pub fn set_status_text(&self, text: &str) -> Result<()> {
        if let Some(window) = self.window.upgrade() {
            window.set_status_text(text.into());
        }
        Ok(())
    }

    /// Update the connection info in the UI.
    /// 
    /// # Errors
    /// Returns an error if updating the UI fails.
    pub fn update_connection_info(&self, info: &NotebookStartResponse) -> Result<()> {
        if let Some(window) = self.window.upgrade() {
            window.set_jupyter_url(format!("https://{}", info.fqdn).into());
            window.set_jupyter_token(info.token.clone().into());
            window.set_notebook_state(info.state.clone().into());
            window.set_connection_ready(true);
        }
        Ok(())
    }

    /// Set the notebook state in the UI.
    /// 
    /// # Errors
    /// Returns an error if updating the UI fails.
    pub fn set_notebook_state(&self, state: &str) -> Result<()> {
        if let Some(window) = self.window.upgrade() {
            window.set_notebook_state(state.into());
        }
        Ok(())
    }

    /// Register callback for refresh button.
    /// 
    /// # Errors
    /// Returns an error if registering the callback fails.
    pub fn on_refresh<F>(&self, callback: F) -> Result<()>
    where
        F: FnMut() + 'static,
    {
        if let Some(window) = self.window.upgrade() {
            window.on_refresh_clicked(callback);
        }
        Ok(())
    }

    /// Register callback for start notebook button.
    /// 
    /// # Errors
    /// Returns an error if registering the callback fails.
    pub fn on_start_notebook<F>(&self, callback: F) -> Result<()>
    where
        F: FnMut(i32, i32) + 'static,
    {
        if let Some(window) = self.window.upgrade() {
            window.on_start_notebook(callback);
        }
        Ok(())
    }

    /// Register callback for connect session button.
    /// 
    /// # Errors
    /// Returns an error if registering the callback fails.
    pub fn on_connect_session<F>(&self, callback: F) -> Result<()>
    where
        F: FnMut(SharedString) + 'static,
    {
        if let Some(window) = self.window.upgrade() {
            window.on_connect_session(callback);
        }
        Ok(())
    }

    /// Show a notification.
    /// 
    /// # Errors
    /// Returns an error if showing the notification fails.
    pub fn show_notification(&self, message: &str) -> Result<()> {
        if let Some(window) = self.window.upgrade() {
            let status = format!("Notification: {message}");
            let prev_status = window.get_status_text();
            window.set_status_text(status.clone().into());

            let window_weak = window.as_weak();
            smol::spawn(async move {
                smol::Timer::after(Duration::from_secs(5)).await;
                if let Some(window) = window_weak.upgrade() {
                    if window.get_status_text() == status {
                        window.set_status_text(prev_status);
                    }
                }
            })
            .detach();
        }
        Ok(())
    }
}
