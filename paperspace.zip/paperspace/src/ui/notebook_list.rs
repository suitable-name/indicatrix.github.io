use crate::{models::notebook::Notebook, ui::MainWindow, ui::NotebookItem};
use anyhow::Result;
use slint::{ModelRc, SharedString, VecModel};

/// UI component for displaying and selecting notebooks.
///
/// `NotebookList` is now a sub-component (`inherits Rectangle`) embedded
/// inside `MainWindow`, so there is no standalone `NotebookList::new()`.
/// This controller delegates to a `MainWindow` weak handle instead.
pub struct NotebookListController {
    window: slint::Weak<MainWindow>,
}

impl NotebookListController {
    /// Create a controller that wraps an existing `MainWindow` weak handle.
    #[must_use]
    pub fn from_window(window: slint::Weak<MainWindow>) -> Self {
        Self { window }
    }

    /// Update the list of notebooks displayed in the main window.
    ///
    /// # Errors
    /// Returns an error if the window handle has been dropped.
    pub fn update_notebooks(&self, notebooks: &[Notebook]) -> Result<()> {
        if let Some(window) = self.window.upgrade() {
            let notebook_data: Vec<_> = notebooks
                .iter()
                .enumerate()
                .map(|(i, notebook)| NotebookItem {
                    id: SharedString::from((i + 1).to_string()),
                    project: SharedString::from(notebook.project.clone()),
                    name: SharedString::from(notebook.name.clone()),
                    handle: SharedString::from(notebook.handle.clone()),
                    state: SharedString::from(notebook.state.clone()),
                    vm_type: SharedString::from(notebook.vm_type.clone()),
                    cluster_id: SharedString::from(notebook.cluster_id.clone()),
                })
                .collect();

            window.set_notebooks(ModelRc::new(VecModel::from(notebook_data)));
        }
        Ok(())
    }

    /// Register a callback invoked when the selected notebook index changes.
    ///
    /// Selection is tracked on `MainWindow` via `selected_notebook`; this
    /// method is a no-op stub kept for API compatibility — callers should
    /// use `MainWindow::on_start_notebook` directly for full selection
    /// handling.
    ///
    /// # Errors
    /// Always returns `Ok(())`.
    pub fn on_selected_row_changed<F>(&self, _callback: F) -> Result<()>
    where
        F: FnMut(i32) + 'static,
    {
        Ok(())
    }
}
