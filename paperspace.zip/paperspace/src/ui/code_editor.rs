use crate::ui::CodeEditorComp;
use anyhow::Result;
use slint::{ComponentHandle, SharedString};
use std::rc::Rc;

/// UI component for code editing and execution
#[derive(Clone)]
pub struct CodeEditor {
    component: Rc<CodeEditorComp>,
}

impl CodeEditor {
    /// Create a new code editor component
    /// 
    /// # Errors
    /// Returns an error if component creation fails.
    pub fn new() -> Result<Self> {
        let component = CodeEditorComp::new()?;
        Ok(Self {
            component: Rc::new(component),
        })
    }

    /// Show the code editor as a popup window
    /// 
    /// # Errors
    /// Returns an error if the window cannot be shown.
    pub fn show(&self) -> Result<()> {
        self.component.window().show()?;
        Ok(())
    }

    /// Hide the code editor window
    /// 
    /// # Errors
    /// Returns an error if the window cannot be hidden.
    pub fn hide(&self) -> Result<()> {
        self.component.window().hide()?;
        Ok(())
    }

    /// Set the code in the editor
    /// 
    /// # Errors
    /// Returns an error if setting the code fails.
    pub fn set_code(&self, code: &str) -> Result<()> {
        self.component.set_code(code.into());
        Ok(())
    }

    /// Get the code from the editor
    /// 
    /// # Errors
    /// Returns an error if retrieving the code fails.
    pub fn get_code(&self) -> Result<String> {
        Ok(self.component.get_code().to_string())
    }

    /// Set the output text
    /// 
    /// # Errors
    /// Returns an error if setting the output fails.
    pub fn set_output(&self, output: &str) -> Result<()> {
        self.component.set_output(output.into());
        Ok(())
    }

    /// Append to the output text
    /// 
    /// # Errors
    /// Returns an error if appending to the output fails.
    pub fn append_output(&self, text: &str) -> Result<()> {
        let current = self.component.get_output().to_string();
        self.component.set_output(format!("{current}{text}").into());
        Ok(())
    }

    /// Set the executing state
    /// 
    /// # Errors
    /// Returns an error if setting the executing state fails.
    pub fn set_executing(&self, executing: bool) -> Result<()> {
        self.component.set_is_executing(executing);
        Ok(())
    }

    /// Set callback for code execution
    /// 
    /// # Errors
    /// Returns an error if setting the callback fails.
    pub fn on_execute_code<F>(&self, callback: F) -> Result<()>
    where
        F: FnMut(SharedString) + 'static,
    {
        self.component.on_execute_code(callback);
        Ok(())
    }

    /// Set callback for loading a file
    /// 
    /// # Errors
    /// Returns an error if setting the callback fails.
    pub fn on_load_file<F>(&self, callback: F) -> Result<()>
    where
        F: FnMut() + 'static,
    {
        self.component.on_load_file(callback);
        Ok(())
    }

    /// Set callback for saving a file
    /// 
    /// # Errors
    /// Returns an error if setting the callback fails.
    pub fn on_save_file<F>(&self, callback: F) -> Result<()>
    where
        F: FnMut(SharedString) + 'static,
    {
        self.component.on_save_file(callback);
        Ok(())
    }

    /// Set callback for when the close button is clicked
    /// 
    /// # Errors
    /// Returns an error if setting the callback fails.
    pub fn on_close<F>(&self, callback: F) -> Result<()>
    where
        F: FnMut() + 'static,
    {
        self.component.on_close(callback);
        Ok(())
    }
}
