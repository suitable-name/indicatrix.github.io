use crate::ui::TerminalViewComp;
use anyhow::Result;
use slint::{ComponentHandle, SharedString};
use std::rc::Rc;

/// UI component for terminal interaction
#[derive(Clone)]
pub struct TerminalView {
    pub component: Rc<TerminalViewComp>,
}

impl TerminalView {
    /// Create a new terminal view component
    /// 
    /// # Errors
    /// Returns an error if component creation fails.
    pub fn new() -> Result<Self> {
        let component = TerminalViewComp::new()?;
        Ok(Self {
            component: Rc::new(component),
        })
    }

    /// Show the terminal view as a popup window
    /// 
    /// # Errors
    /// Returns an error if the window cannot be shown.
    pub fn show(&self) -> Result<()> {
        self.component.window().show()?;
        Ok(())
    }

    /// Hide the terminal view window
    /// 
    /// # Errors
    /// Returns an error if the window cannot be hidden.
    pub fn hide(&self) -> Result<()> {
        self.component.window().hide()?;
        Ok(())
    }

    /// Set the output text
    /// 
    /// # Errors
    /// Returns an error if setting the output fails.
    pub fn set_output(&self, output: &str) -> Result<()> {
        self.component.set_output(output.into());
        Ok(())
    }

    /// Append to the output text
    /// 
    /// # Errors
    /// Returns an error if appending to the output fails.
    pub fn append_output(&self, text: &str) -> Result<()> {
        let current = self.component.get_output().to_string();
        self.component.set_output(format!("{current}{text}").into());
        Ok(())
    }

    /// Set the current command
    /// 
    /// # Errors
    /// Returns an error if setting the command fails.
    pub fn set_current_command(&self, command: &str) -> Result<()> {
        self.component.set_current_command(command.into());
        Ok(())
    }

    /// Get the current command
    /// 
    /// # Errors
    /// Returns an error if retrieving the command fails.
    pub fn get_current_command(&self) -> Result<String> {
        Ok(self.component.get_current_command().to_string())
    }

    /// Set the executing state
    /// 
    /// # Errors
    /// Returns an error if setting the executing state fails.
    pub fn set_executing(&self, executing: bool) -> Result<()> {
        self.component.set_is_executing(executing);
        Ok(())
    }

    /// Set callback for sending a command
    /// 
    /// # Errors
    /// Returns an error if setting the callback fails.
    pub fn on_send_command<F>(&self, callback: F) -> Result<()>
    where
        F: FnMut(SharedString) + 'static,
    {
        self.component.on_send_command(callback);
        Ok(())
    }

    /// Set callback for sending a special key
    /// 
    /// # Errors
    /// Returns an error if setting the callback fails.
    pub fn on_send_special_key<F>(&self, callback: F) -> Result<()>
    where
        F: FnMut(SharedString) + 'static,
    {
        self.component.on_send_special_key(callback);
        Ok(())
    }

    /// Set callback when input is accepted (`LineEdit` Enter pressed)
    /// 
    /// # Errors
    /// Returns an error if setting the callback fails.
    pub fn on_input_accepted<F>(&self, callback: F) -> Result<()>
    where
        F: FnMut() + 'static,
    {
        self.component.on_input_accepted(callback);
        Ok(())
    }

    /// Set callback for when the close button is clicked
    /// 
    /// # Errors
    /// Returns an error if setting the callback fails.
    pub fn on_close<F>(&self, callback: F) -> Result<()>
    where
        F: FnMut() + 'static,
    {
        self.component.on_close(callback);
        Ok(())
    }
}
