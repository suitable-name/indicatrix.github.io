pub mod app;
pub mod code_editor;
pub mod machine_types;
pub mod notebook_list;
pub mod progress;
pub mod terminal_view;

slint::include_modules!();

pub use app::MainWindowController;
pub use code_editor::CodeEditor;
pub use machine_types::MachineTypeListController;
pub use notebook_list::NotebookListController;
pub use progress::ConnectionProgress;
pub use terminal_view::TerminalView;
