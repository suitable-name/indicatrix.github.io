use super::{MachineTypeItem, MainWindow};
use crate::models::notebook::LabelAvailability;
use anyhow::Result;
use slint::{ModelRc, SharedString, VecModel};

/// Controller for the machine-type list embedded in `MainWindow`.
///
/// `MachineTypeList` is now a sub-component (`inherits Rectangle`) embedded
/// inside `MainWindow`, so there is no standalone `MachineTypeList::new()`.
/// This controller delegates to a `MainWindow` weak handle instead.
pub struct MachineTypeListController {
    window: slint::Weak<MainWindow>,
}

impl MachineTypeListController {
    /// Create a controller that wraps an existing `MainWindow` weak handle.
    #[must_use]
    pub fn from_window(window: slint::Weak<MainWindow>) -> Self {
        Self { window }
    }

    /// Update the list of machine types displayed in the main window.
    ///
    /// # Errors
    /// Returns an error if the window handle has been dropped.
    pub fn update_machine_types(&self, machine_types: &[LabelAvailability]) -> Result<()> {
        if let Some(window) = self.window.upgrade() {
            let machine_type_data: Vec<_> = machine_types
                .iter()
                .enumerate()
                .map(|(i, mt)| MachineTypeItem {
                    id: SharedString::from((i + 1).to_string()),
                    label: SharedString::from(mt.label.clone()),
                    available: mt.is_available,
                })
                .collect();

            window.set_machine_types(ModelRc::new(VecModel::from(machine_type_data)));
        }
        Ok(())
    }

    /// Register a callback invoked when the selected machine-type index changes.
    ///
    /// Selection is tracked on `MainWindow` via `selected_machine_type`; this
    /// method is a no-op stub kept for API compatibility — callers should use
    /// `MainWindow::on_start_notebook` directly for full selection handling.
    ///
    /// # Errors
    /// Always returns `Ok(())`.
    pub fn on_selected_row_changed<F>(&self, _callback: F) -> Result<()>
    where
        F: FnMut(i32) + 'static,
    {
        Ok(())
    }
}
