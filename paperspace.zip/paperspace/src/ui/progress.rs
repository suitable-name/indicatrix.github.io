use crate::ui::ConnectionProgressComp;
use anyhow::Result;
use slint::ComponentHandle;
use std::rc::Rc;

/// Small popup window showing the progress of a long-running connect/start
/// operation, with a countdown progress bar and a Cancel button.
#[derive(Clone)]
pub struct ConnectionProgress {
    component: Rc<ConnectionProgressComp>,
}

impl ConnectionProgress {
    /// Create the progress popup component.
    ///
    /// # Errors
    /// Returns an error if component creation fails.
    pub fn new() -> Result<Self> {
        Ok(Self {
            component: Rc::new(ConnectionProgressComp::new()?),
        })
    }

    /// Show the popup window.
    ///
    /// # Errors
    /// Returns an error if the window cannot be shown.
    pub fn show(&self) -> Result<()> {
        self.component.window().show()?;
        Ok(())
    }

    /// Hide the popup window.
    ///
    /// # Errors
    /// Returns an error if the window cannot be hidden.
    pub fn hide(&self) -> Result<()> {
        self.component.window().hide()?;
        Ok(())
    }

    /// Set the main status line.
    pub fn set_status(&self, status: &str) {
        self.component.set_status(status.into());
    }

    /// Set the detail / countdown line.
    pub fn set_detail(&self, detail: &str) {
        self.component.set_detail(detail.into());
    }

    /// Set the progress fraction (clamped to `0.0..=1.0`).
    pub fn set_progress(&self, progress: f32) {
        self.component.set_progress(progress.clamp(0.0, 1.0));
    }

    /// Switch between indeterminate (spinner) and determinate (bar) display.
    pub fn set_indeterminate(&self, indeterminate: bool) {
        self.component.set_indeterminate(indeterminate);
    }

    /// Register the Cancel button callback.
    pub fn on_cancel<F>(&self, callback: F)
    where
        F: FnMut() + 'static,
    {
        self.component.on_cancel(callback);
    }
}
