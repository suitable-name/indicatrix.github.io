use super::kernel::Kernel;
use serde::{Deserialize, Serialize};

/// Represents a Jupyter session
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Session {
    pub id: String,
    pub kernel: Kernel,
}

impl Session {
    /// Creates a new session with the given id and kernel
    #[must_use]
    pub fn new(id: String, kernel: Kernel) -> Self {
        Self { id, kernel }
    }
}
