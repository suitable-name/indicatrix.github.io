use serde::{Deserialize, Serialize};

/// Represents a Jupyter terminal
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Terminal {
    pub name: String,
}

impl Terminal {
    /// Creates a new terminal with the given name
    #[must_use]
    pub fn new(name: String) -> Self {
        Self { name }
    }
}
