use serde::{Deserialize, Serialize};
use std::collections::HashMap;

/// Response containing a list of notebooks
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct NotebookListResponse {
    #[serde(rename = "notebookList")]
    pub notebook_list: Vec<Notebook>,
}

/// Represents a Paperspace notebook
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Notebook {
    #[serde(rename = "clusterId")]
    pub cluster_id: String,
    pub id: u32,
    pub project: String,
    pub name: String,
    pub handle: String,
    pub state: String,
    #[serde(rename = "vmType")]
    pub vm_type: String,
    #[serde(rename = "dtStarted")]
    pub started: Option<String>,
    pub token: Option<String>,
    pub fqdn: Option<String>,
}

/// Request to start a notebook
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct NotebookStartRequest {
    #[serde(rename = "notebookId")]
    pub notebook_id: u32,
    #[serde(rename = "notebookName")]
    pub notebook_name: String,
    #[serde(rename = "vmTypeLabel")]
    pub vm_type_label: String,
    #[serde(rename = "clusterId")]
    pub cluster_id: String,
    #[serde(rename = "isPreemptible")]
    pub is_preemptible: Option<bool>,
    #[serde(rename = "shutdownTimeout")]
    pub shutdown_timeout: i32,
    #[serde(rename = "teamId")]
    pub team_id: i32,
}

impl NotebookStartRequest {
    /// Create a new notebook start request
    #[must_use]
    pub fn new(notebook: &Notebook, machine_type: &LabelAvailability) -> Self {
        Self {
            notebook_id: notebook.id,
            notebook_name: notebook.name.clone(),
            vm_type_label: machine_type.label.clone(),
            cluster_id: notebook.cluster_id.clone(),
            is_preemptible: Some(false),
            shutdown_timeout: 6,
            team_id: 1_156_277,
        }
    }
}

/// Response from starting a notebook
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct NotebookStartResponse {
    pub project: String,
    pub handle: String,
    pub state: String,
    pub fqdn: String,
    pub token: String,
}

/// Request for listing notebooks
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct NotebookListRequest {
    #[serde(rename = "where")]
    pub where_: WhereClause,
    pub limit: i32,
    pub order: String,
    pub offset: i32,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct WhereClause {
    #[serde(rename = "dtDeleted")]
    pub dt_deleted: Option<serde_json::Value>,
}

impl Default for NotebookListRequest {
    fn default() -> Self {
        Self::new()
    }
}

impl NotebookListRequest {
    /// Create a new notebook list request with default values
    #[must_use]
    pub fn new() -> Self {
        Self {
            where_: WhereClause { dt_deleted: None },
            limit: 20,
            order: "jobId desc".to_string(),
            offset: 0,
        }
    }
}

/// Represents a VM type with its availability
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct VmType {
    pub label: String,
}

/// Represents a cluster with VM type and availability
#[derive(Debug, Deserialize)]
pub struct ClusterMachineType {
    #[serde(rename = "isAvailable")]
    pub is_available: bool,
    #[serde(rename = "vmTypeId")]
    pub vm_type_id: u64,
    #[serde(rename = "vmType")]
    pub vm_type: VmType,
}

/// Machine type response from the API
#[derive(Debug, Deserialize)]
pub struct MachineTypeResponse {
    #[serde(flatten)]
    pub clusters: HashMap<String, Vec<ClusterMachineType>>,
}

/// Simplified structure for machine type with availability
#[derive(Clone, Debug, Deserialize, Serialize)]
pub struct LabelAvailability {
    pub label: String,
    pub is_available: bool,
    pub vm_type_id: u64,
}

impl NotebookListResponse {
    /// Find a notebook by handle
    #[must_use]
    pub fn find_by_handle(&self, handle: &str) -> Option<&Notebook> {
        self.notebook_list.iter().find(|n| n.handle == handle)
    }
}
