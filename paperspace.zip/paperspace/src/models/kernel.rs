use serde::{Deserialize, Serialize};
use uuid::Uuid;
use std::collections::HashMap;

/// Represents a Jupyter kernel
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Kernel {
    /// The unique identifier of the kernel
    #[serde(rename = "id")]
    pub id: String,
}

/// Header field of a Jupyter wire-protocol message.
#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct MessageHeader {
    #[serde(default)]
    pub msg_type: String,
}

/// Represents a websocket message for kernel communication.
///
/// Real Jupyter messages place the type in `header.msg_type`, not at the top
/// level.  The old top-level `msg_type` field has been removed; use the
/// [`WebSocketMessage::msg_type`] helper instead.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct WebSocketMessage {
    #[serde(default)]
    pub header: MessageHeader,
    #[serde(rename = "content", skip_serializing_if = "Option::is_none")]
    pub content: Option<serde_json::Value>,
    #[serde(default)]
    pub channel: Option<String>,
}

impl WebSocketMessage {
    /// Return the `msg_type` from the message header.
    #[must_use]
    pub fn msg_type(&self) -> &str {
        &self.header.msg_type
    }
}

/// Represents an execute request to a Jupyter kernel
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ExecuteRequest {
    /// Top-level channel field required by `jupyter_server` multiplexed protocol
    pub channel: String,
    pub header: HashMap<String, serde_json::Value>,
    #[serde(rename = "parent_header")]
    pub parent_header: HashMap<String, serde_json::Value>,
    pub metadata: HashMap<String, serde_json::Value>,
    pub content: HashMap<String, serde_json::Value>,
    pub buffers: Vec<String>,
}

impl ExecuteRequest {
    /// Create a new execute request for the given code and session
    #[must_use]
    pub fn new(code: &str, session_id: &str) -> Self {
        let msg_id = format!("execute_{}", Uuid::new_v4());

        let mut content = HashMap::new();
        content.insert("code".to_string(), serde_json::Value::String(code.to_string()));
        content.insert("silent".to_string(), serde_json::Value::Bool(false));
        content.insert("store_history".to_string(), serde_json::Value::Bool(true));
        content.insert(
            "user_expressions".to_string(),
            serde_json::Value::Object(serde_json::Map::new()),
        );
        content.insert("allow_stdin".to_string(), serde_json::Value::Bool(false));

        let mut header = HashMap::new();
        header.insert("msg_id".to_string(), serde_json::Value::String(msg_id));
        header.insert(
            "username".to_string(),
            serde_json::Value::String("username".to_string()),
        );
        header.insert(
            "session".to_string(),
            serde_json::Value::String(session_id.to_string()),
        );
        header.insert(
            "msg_type".to_string(),
            serde_json::Value::String(message_types::EXECUTE_REQUEST.to_string()),
        );
        header.insert(
            "version".to_string(),
            serde_json::Value::String("5.2".to_string()),
        );

        ExecuteRequest {
            channel: "shell".to_string(),
            header,
            parent_header: HashMap::new(),
            metadata: HashMap::new(),
            content,
            buffers: vec![],
        }
    }
}

/// Constants for WebSocket message types
pub mod message_types {
    pub const EXECUTE_REQUEST: &str = "execute_request";
    pub const EXECUTE_RESULT: &str = "execute_result";
    pub const EXECUTE_REPLY: &str = "execute_reply";
    pub const STREAM: &str = "stream";
    pub const ERROR: &str = "error";
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn execute_request_has_channel_shell_and_correct_msg_type() {
        let req = ExecuteRequest::new("print('hi')", "sess-123");
        let json_val = serde_json::to_value(&req).expect("serialization failed");

        assert_eq!(
            json_val.get("channel").and_then(|v| v.as_str()),
            Some("shell"),
            "channel field must be \"shell\""
        );

        let header_msg_type = json_val
            .get("header")
            .and_then(|h| h.get("msg_type"))
            .and_then(|v| v.as_str());
        assert_eq!(
            header_msg_type,
            Some("execute_request"),
            "header.msg_type must be \"execute_request\""
        );
    }

    #[test]
    fn websocket_message_deserializes_header_msg_type() {
        let raw = r#"{"header":{"msg_type":"stream"},"content":{"text":"hi"},"channel":"iopub"}"#;
        let msg: WebSocketMessage = serde_json::from_str(raw).expect("deserialization failed");

        assert_eq!(msg.msg_type(), "stream");
        assert_eq!(msg.channel.as_deref(), Some("iopub"));
        let text = msg
            .content
            .as_ref()
            .and_then(|c| c.get("text"))
            .and_then(|v| v.as_str());
        assert_eq!(text, Some("hi"));
    }
}
