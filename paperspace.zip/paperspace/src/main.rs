use anyhow::Result;
use async_lock::Mutex;
use paperspace_ui::{
    api::machine_types::is_machine_type_available,
    get_available_machine_types, get_notebooks,
    models::notebook::NotebookStartResponse,
    start_notebook,
    ui::{
        code_editor::CodeEditor,
        progress::ConnectionProgress,
        terminal_view::TerminalView,
        MachineTypeItem, MainWindow, NotebookItem,
    },
    CodeExecutor, KernelManager, LabelAvailability, Notebook,
    NotebookListResponse, SessionManager, TerminalExecutor, TerminalManager,
};
use slint::ComponentHandle;
use std::cell::RefCell;
use std::rc::Rc;
use std::sync::Arc;

// Main function
/// # Errors
/// Returns an error if the application fails to initialize or run.
pub fn main() -> Result<()> {
    smol::block_on(async {
        // API tokens
        let machine_type_token = "<TOKEN>";

        // Create and show the UI
        let ui = MainWindow::new()?;
        let terminal_view = Rc::new(TerminalView::new()?);
        let code_editor = Rc::new(CodeEditor::new()?);
        let progress = ConnectionProgress::new()?;

        // Store data for UI updates - use Arc<Mutex> for thread safety
        let notebook_list = Arc::new(Mutex::new(NotebookListResponse {
            notebook_list: Vec::new(),
        }));
        let machine_types = Arc::new(Mutex::new(Vec::<LabelAvailability>::new()));
        let connection_info = Arc::new(Mutex::new(Option::<NotebookStartResponse>::None));

        // Set up UI callbacks
        setup_ui_callbacks(
            &ui,
            machine_type_token,
            &notebook_list,
            &machine_types,
            connection_info.clone(),
            terminal_view.clone(),
            code_editor.clone(),
            &progress,
        );

        // Load initial data
        load_initial_data(
            &ui,
            machine_type_token,
            notebook_list.clone(),
            machine_types.clone(),
        )
        .await?;

        // Show the UI
        ui.run()?;

        Ok(())
    })
}

/// Update the progress popup as a wait interval elapses, so the user sees how
/// long until the next retry. Driven by the surrounding `or(..)` race for
/// cancellation, so it needs no internal cancel check.
async fn countdown(progress: &ConnectionProgress, total_secs: u64, attempt: u32, label: &str) {
    let total_ms = total_secs * 1000;
    let step_ms = 150_u64;
    let mut elapsed = 0_u64;
    progress.set_progress(0.0);
    while elapsed < total_ms {
        let remaining = (total_ms - elapsed).div_ceil(1000);
        progress.set_detail(&format!("Attempt {attempt} — {label} {remaining}s"));
        #[allow(clippy::cast_precision_loss)]
        progress.set_progress(elapsed as f32 / total_ms as f32);
        smol::Timer::after(std::time::Duration::from_millis(step_ms)).await;
        elapsed += step_ms;
    }
    progress.set_progress(1.0);
}

#[allow(clippy::too_many_arguments, clippy::too_many_lines)]
fn setup_ui_callbacks(
    ui: &MainWindow,
    machine_type_token: &str,
    notebook_list: &Arc<Mutex<NotebookListResponse>>,
    machine_types: &Arc<Mutex<Vec<LabelAvailability>>>,
    connection_info: Arc<Mutex<Option<NotebookStartResponse>>>,
    terminal_view: Rc<TerminalView>,
    code_editor: Rc<CodeEditor>,
    progress: &ConnectionProgress,
) {
    let ui_handle = ui.as_weak();
    let machine_type_token = machine_type_token.to_string();

    // Handle refresh button
    let ui_refresh = ui_handle.clone();
    let mt_refresh = machine_type_token.clone();
    let notebooks_refresh = notebook_list.clone();
    let types_refresh = machine_types.clone();
    ui.on_refresh_clicked(move || {
        let ui = ui_refresh.clone();
        let mt = mt_refresh.clone();
        let notebooks = notebooks_refresh.clone();
        let types = types_refresh.clone();

        if let Err(e) =
            slint::spawn_local(async move { refresh_data(&ui, &mt, notebooks, types).await })
        {
            eprintln!("Error refreshing data: {e}");
        }
    });

    // Shared slot holding the cancel sender for the in-flight operation.
    let cancel_slot: Rc<RefCell<Option<smol::channel::Sender<()>>>> =
        Rc::new(RefCell::new(None));

    // Register the popup's Cancel button once — shared between start and connect.
    let progress_cancel = progress.clone();
    let cancel_slot_cancel = cancel_slot.clone();
    progress.on_cancel(move || {
        if let Some(tx) = cancel_slot_cancel.borrow_mut().take() {
            let _ = tx.try_send(());
        }
        let _ = progress_cancel.hide();
    });

    // Handle start notebook button
    let ui_start = ui_handle.clone();
    let mt_start = machine_type_token.clone();
    let notebooks_start = notebook_list.clone();
    let types_start = machine_types.clone();
    let conn_info = connection_info.clone();
    let cancel_slot_start = cancel_slot.clone();
    let progress_start = progress.clone();
    ui.on_start_notebook(move |notebook_idx, machine_type_idx| {
        let ui = ui_start.clone();
        let mt = mt_start.clone();
        let notebooks = notebooks_start.clone();
        let types = types_start.clone();
        let conn = conn_info.clone();
        let progress = progress_start.clone();
        let cancel_slot = cancel_slot_start.clone();

        // Set up cancellation channel and show popup.
        let (cancel_tx, cancel_rx) = smol::channel::bounded::<()>(1);
        *cancel_slot.borrow_mut() = Some(cancel_tx);

        progress.set_indeterminate(false);
        progress.set_status("Starting notebook...");
        progress.set_progress(0.0);
        if let Err(e) = progress.show() {
            eprintln!("Error showing progress popup: {e}");
        }

        let progress_task = progress.clone();
        let cancel_slot_task = cancel_slot.clone();
        if let Err(e) = slint::spawn_local(async move {
            let notebook_idx = usize::try_from(notebook_idx).unwrap_or(0);
            let machine_type_idx = usize::try_from(machine_type_idx).unwrap_or(0);

            let start_fut = start_notebook_task(
                ui.clone(),
                notebook_idx,
                machine_type_idx,
                mt,
                notebooks,
                types,
                conn,
                progress_task.clone(),
            );
            let cancel_fut = async move {
                let _ = cancel_rx.recv().await;
                Err::<(), anyhow::Error>(anyhow::anyhow!("Start cancelled by user"))
            };
            let result = futures_lite::future::or(start_fut, cancel_fut).await;

            let _ = progress_task.hide();
            *cancel_slot_task.borrow_mut() = None;
            if let Some(ui) = ui.upgrade() {
                ui.set_loading(false);
                if let Err(e) = result {
                    ui.set_status_text(format!("{e}").into());
                }
            }
        }) {
            eprintln!("Error starting notebook: {e}");
            let _ = progress_start.hide();
            *cancel_slot_start.borrow_mut() = None;
            if let Some(ui) = ui_start.upgrade() {
                ui.set_loading(false);
                ui.set_status_text(format!("Error: {e}").into());
            }
        }
    });

    // Handle connect to kernel/terminal button
    let ui_connect = ui_handle.clone();
    let conn_info_connect = connection_info;
    let cancel_slot_connect = cancel_slot.clone();
    let progress_connect = progress.clone();
    ui.on_connect_session(move |session_type| {
        let conn = conn_info_connect.clone();
        let is_kernel = session_type == "kernel";
        let terminal_view_clone = terminal_view.clone();
        let code_editor_clone = code_editor.clone();
        let args: Vec<String> = std::env::args().collect();
        let cancel_slot = cancel_slot_connect.clone();
        let progress = progress_connect.clone();

        // New cancellation channel for this attempt; show the popup.
        let (cancel_tx, cancel_rx) = smol::channel::bounded::<()>(1);
        *cancel_slot.borrow_mut() = Some(cancel_tx);

        progress.set_indeterminate(true);
        progress.set_status(if is_kernel {
            "Connecting to kernel..."
        } else {
            "Connecting to terminal..."
        });
        progress.set_detail("");
        if let Err(e) = progress.show() {
            eprintln!("Error showing progress popup: {e}");
        }

        if let Some(ui) = ui_connect.upgrade() {
            ui.set_connecting(true);
        }

        let ui_for_task = ui_connect.clone();
        let progress_task = progress.clone();
        let cancel_slot_task = cancel_slot.clone();
        if let Err(e) = slint::spawn_local(async move {
            let connect_fut = connect_session_task(
                ui_for_task.clone(),
                conn,
                is_kernel,
                args,
                terminal_view_clone,
                code_editor_clone,
            );
            let cancel_fut = async move {
                let _ = cancel_rx.recv().await;
                Err::<(), anyhow::Error>(anyhow::anyhow!("Connection cancelled by user"))
            };
            let result = futures_lite::future::or(connect_fut, cancel_fut).await;

            let _ = progress_task.hide();
            *cancel_slot_task.borrow_mut() = None;
            if let Some(ui) = ui_for_task.upgrade() {
                ui.set_connecting(false);
                if let Err(e) = result {
                    ui.set_status_text(format!("{e}").into());
                }
            }
        }) {
            eprintln!("Error connecting to session: {e}");
            let _ = progress_connect.hide();
            *cancel_slot_connect.borrow_mut() = None;
            if let Some(ui) = ui_connect.upgrade() {
                ui.set_connecting(false);
                ui.set_status_text(format!("Error: {e}").into());
            }
        }
    });

    // Consume the final clone of cancel_slot to satisfy the borrow checker.
    // (The cancel button is wired via progress.on_cancel above.)
    drop(cancel_slot);
}

async fn load_initial_data(
    ui: &MainWindow,
    machine_type_token: &str,
    notebook_list: Arc<Mutex<NotebookListResponse>>,
    machine_types: Arc<Mutex<Vec<LabelAvailability>>>,
) -> Result<()> {
    ui.set_loading(true);
    ui.set_status_text("Loading data...".into());

    // Fetch data concurrently
    let (labels, notebooks) = futures::join!(
        get_available_machine_types(machine_type_token),
        get_notebooks(machine_type_token)
    );

    let labels = labels?;
    let notebooks = notebooks?;

    // Store data in shared state
    {
        let mut mt = machine_types.lock().await;
        (*mt).clone_from(&labels);
    }

    {
        let mut nl = notebook_list.lock().await;
        *nl = notebooks;
    }

    // Update UI
    update_notebook_list(ui, &notebook_list.lock().await.notebook_list);
    update_machine_types(ui, &labels);

    ui.set_loading(false);
    ui.set_status_text("Ready".into());

    Ok(())
}

async fn refresh_data(
    ui_handle: &slint::Weak<MainWindow>,
    machine_type_token: &str,
    notebook_list: Arc<Mutex<NotebookListResponse>>,
    machine_types: Arc<Mutex<Vec<LabelAvailability>>>,
) -> Result<()> {
    if let Some(ui) = ui_handle.upgrade() {
        ui.set_loading(true);
        ui.set_status_text("Refreshing data...".into());
    }

    // Fetch data concurrently
    let (labels, notebooks) = futures::join!(
        get_available_machine_types(machine_type_token),
        get_notebooks(machine_type_token)
    );

    let labels = labels?;
    let notebooks = notebooks?;

    // Store data in shared state
    {
        let mut mt = machine_types.lock().await;
        (*mt).clone_from(&labels);
    }

    {
        let mut nl = notebook_list.lock().await;
        *nl = notebooks;
    }

    // Update UI
    if let Some(ui) = ui_handle.upgrade() {
        update_notebook_list(&ui, &notebook_list.lock().await.notebook_list);
        update_machine_types(&ui, &labels);

        ui.set_loading(false);
        ui.set_status_text("Data refreshed".into());
    }

    Ok(())
}

#[allow(clippy::too_many_arguments)]
async fn start_notebook_task(
    ui_handle: slint::Weak<MainWindow>,
    notebook_idx: usize,
    machine_type_idx: usize,
    machine_type_token: String,
    notebook_list: Arc<Mutex<NotebookListResponse>>,
    machine_types: Arc<Mutex<Vec<LabelAvailability>>>,
    connection_info: Arc<Mutex<Option<NotebookStartResponse>>>,
    progress: ConnectionProgress,
) -> Result<()> {
    if let Some(ui) = ui_handle.upgrade() {
        ui.set_loading(true);
        ui.set_status_text("Starting notebook...".into());
    }

    // Get selected notebook and machine type
    let selected_notebook: Notebook;
    let selected_machine_type: LabelAvailability;

    {
        let notebooks = notebook_list.lock().await;
        selected_notebook = notebooks
            .notebook_list
            .get(notebook_idx)
            .ok_or_else(|| anyhow::anyhow!("Invalid notebook selection"))?
            .clone();
    }

    {
        let machine_types = machine_types.lock().await;
        selected_machine_type = machine_types
            .get(machine_type_idx)
            .ok_or_else(|| anyhow::anyhow!("Invalid machine type selection"))?
            .clone();
    }

    // Poll machine availability with countdown, driving the popup.
    let mut attempt = 0_u32;
    loop {
        let labels = get_available_machine_types(&machine_type_token).await?;
        if is_machine_type_available(&selected_machine_type.label, &labels) {
            break;
        }
        attempt += 1;
        progress.set_status(&format!(
            "Machine '{}' is unavailable",
            selected_machine_type.label
        ));
        countdown(&progress, 10, attempt, "next check in").await;
    }

    progress.set_indeterminate(true);
    progress.set_status("Starting notebook...");
    progress.set_detail("Sending start request...");

    // Start the notebook (start_notebook internally calls check_availability,
    // but since we already confirmed availability above it will proceed
    // immediately for the common case).
    let response = start_notebook(
        &selected_notebook,
        &selected_machine_type,
        &machine_type_token,
    )
    .await?;

    // Store connection info
    {
        let mut conn = connection_info.lock().await;
        *conn = Some(response.clone());
    }

    // Poll for Running state with countdown, driving the popup.
    progress.set_indeterminate(false);
    progress.set_status("Waiting for notebook to start...");
    let mut attempt = 0_u32;
    let notebook = loop {
        let list = get_notebooks(&machine_type_token).await?;
        if let Some(nb) = list.notebook_list.iter().find(|n| n.handle == response.handle) {
            if nb.state == "Running" {
                break nb.clone();
            }
            progress.set_status(&format!(
                "Waiting for Running (current: {})",
                nb.state
            ));
        } else {
            progress.set_status("Waiting for notebook to appear...");
        }
        attempt += 1;
        countdown(&progress, 10, attempt, "next check in").await;
    };

    // Update UI with connection info
    if let Some(ui) = ui_handle.upgrade() {
        ui.set_jupyter_url(format!("https://{}", response.fqdn).into());
        ui.set_jupyter_token(response.token.clone().into());
        ui.set_notebook_state(notebook.state.into());
        ui.set_connection_ready(true);
        ui.set_loading(false);
        ui.set_status_text("Notebook started successfully".into());
    }

    // Show notification
    #[cfg(target_os = "windows")]
    {
        let _ = std::process::Command::new("cmd")
            .args(["/c", "msg", "*", "Session started!"])
            .spawn();
    }

    Ok(())
}

#[allow(clippy::too_many_lines)]
async fn connect_session_task(
    ui_handle: slint::Weak<MainWindow>,
    connection_info: Arc<Mutex<Option<NotebookStartResponse>>>,
    is_kernel: bool,
    args: Vec<String>,
    terminal_view: Rc<TerminalView>,
    code_editor: Rc<CodeEditor>,
) -> Result<()> {
    if let Some(ui) = ui_handle.upgrade() {
        ui.set_status_text(
            format!(
                "Connecting to {}...",
                if is_kernel { "kernel" } else { "terminal" }
            )
            .into(),
        );
    }

    // Get connection info
    let conn_info = {
        let conn = connection_info.lock().await;
        conn.clone()
            .ok_or_else(|| anyhow::anyhow!("No active notebook connection"))?
    };
    let jupyter_url = format!("https://{}", conn_info.fqdn);
    let jupyter_url_wss = format!("wss://{}", conn_info.fqdn);
    let jupyter_token = conn_info.token.clone();

    if is_kernel {
        // ── FIX 3: single persistent kernel connection ───────────────────────
        let session_manager = SessionManager::new(&jupyter_url, &jupyter_token);
        let (session, is_new_session) = session_manager.resume_session().await?;

        let kernel_manager = KernelManager::new(&jupyter_url, &jupyter_token);
        let (kernel, is_new_kernel) = kernel_manager.get_or_start_kernel().await?;

        let initial_code = if args.len() > 1 {
            let script_path = &args[1];
            Some(smol::fs::read_to_string(script_path).await?)
        } else {
            None
        };

        if let Some(ui) = ui_handle.upgrade() {
            ui.set_status_text(
                format!(
                    "{} session, {} kernel. Connecting to kernel channels...",
                    if is_new_session { "New" } else { "Existing" },
                    if is_new_kernel { "new" } else { "existing" }
                )
                .into(),
            );
        }

        code_editor.set_output("Connecting to kernel...\n")?;
        code_editor.set_executing(true)?;

        // Connect once; reader task spawned inside connect_persistent.
        let write_handle = CodeExecutor::connect_persistent(
            &jupyter_url_wss,
            &jupyter_token,
            &kernel.id,
            (*code_editor).clone(),
        )
        .await?;

        code_editor.set_output("Connected to kernel. Ready for code execution.\n")?;
        // is_executing is reset to false by the reader task when execute_reply
        // arrives; but set it false now so the button is enabled immediately.
        code_editor.set_executing(false)?;

        // Shared write handle (Sender is Clone + 'static)
        let session_id = session.id.clone();
        let wh = write_handle.clone();
        let code_editor_for_callback = code_editor.clone();

        code_editor.on_execute_code(move |code| {
            let code_str = code.to_string();
            let wh2 = wh.clone();
            let sid = session_id.clone();
            let editor = code_editor_for_callback.clone();

            if let Err(e) = slint::spawn_local(async move {
                // Set executing before sending so the button disables.
                let _ = editor.set_executing(true);
                if let Err(e) = CodeExecutor::send_execute_request(&wh2, &code_str, &sid) {
                    eprintln!("Error sending execute request: {e}");
                    let _ = editor.set_executing(false);
                }
            }) {
                eprintln!("Error spawning execution task: {e}");
            }
        })?;

        // Close handler
        let kernel_id_clone = kernel.id.clone();
        let jupyter_url_clone = jupyter_url.clone();
        let jupyter_token_clone = jupyter_token.clone();

        code_editor.on_close(move || {
            let k_id = kernel_id_clone.clone();
            let url = jupyter_url_clone.clone();
            let token = jupyter_token_clone.clone();

            if let Err(e) = slint::spawn_local(async move {
                let client = surf::client();
                let shutdown_url = format!("{url}/api/kernels/{k_id}/shutdown?token={token}");
                if let Err(e) = client.post(shutdown_url).await {
                    eprintln!("Error shutting down kernel: {e}");
                }
            }) {
                eprintln!("Error spawning kernel shutdown task: {e}");
            }
        })?;

        code_editor.show()?;

        // Execute initial code if provided
        if let Some(code) = initial_code {
            code_editor.set_code(&code)?;
            if !code.is_empty() {
                let wh3 = write_handle.clone();
                let sid3 = session.id.clone();
                let editor3 = code_editor.clone();
                if let Err(e) = slint::spawn_local(async move {
                    let _ = editor3.set_executing(true);
                    if let Err(e) = CodeExecutor::send_execute_request(&wh3, &code, &sid3) {
                        eprintln!("Error sending initial execute request: {e}");
                        let _ = editor3.set_executing(false);
                    }
                }) {
                    eprintln!("Error spawning initial code execution: {e}");
                }
            }
        }
    } else {
        // ── FIX 2: single persistent terminal connection ──────────────────────
        let terminal_manager = TerminalManager::new(&jupyter_url, &jupyter_token);
        let (terminal, is_new_terminal) = terminal_manager.get_or_create_terminal().await?;

        let initial_command = if args.len() > 1 {
            let script_path = &args[1];
            Some(smol::fs::read_to_string(script_path).await?)
        } else {
            None
        };

        if let Some(ui) = ui_handle.upgrade() {
            ui.set_status_text(
                format!(
                    "{} terminal. Connecting...",
                    if is_new_terminal { "New" } else { "Existing" }
                )
                .into(),
            );
        }

        terminal_view.set_output("Connecting to terminal...\n")?;
        // is_executing = true while connecting; connect_persistent clears it
        // once the reader is live.
        terminal_view.set_executing(true)?;

        // Connect once; reader/writer tasks spawned inside connect_persistent.
        let write_handle = TerminalExecutor::connect_persistent(
            &jupyter_url_wss,
            &jupyter_token,
            terminal.clone(),
            (*terminal_view).clone(),
        )
        .await?;

        terminal_view.set_output("Connected to terminal. Ready for commands.\n")?;

        // ── on_send_command: write command on the existing connection ─────────
        let wh_cmd = write_handle.clone();
        let terminal_view_for_command = terminal_view.clone();
        terminal_view.on_send_command(move |command| {
            let command_str = command.to_string();
            let wh = wh_cmd.clone();
            let tv = terminal_view_for_command.clone();

            if let Err(e) = slint::spawn_local(async move {
                if let Err(e) = TerminalExecutor::send_command_on_handle(&wh, &command_str) {
                    eprintln!("Error sending command: {e}");
                    let _ = tv.append_output(&format!("\nError sending command: {e}\n"));
                }
            }) {
                eprintln!("Error spawning send_command task: {e}");
            }
        })?;

        // ── on_send_special_key: map key names to raw control bytes ──────────
        let wh_key = write_handle.clone();
        let terminal_view_for_key = terminal_view.clone();
        terminal_view.on_send_special_key(move |key| {
            let raw: &str = match key.as_str() {
                "ctrl+c" => "\x03",
                "ctrl+d" => "\x04",
                "ctrl+\\" => "\x1c",
                other => {
                    eprintln!("Unknown special key: {other}");
                    return;
                }
            };
            let raw_owned = raw.to_string();
            let wh = wh_key.clone();
            let tv = terminal_view_for_key.clone();

            if let Err(e) = slint::spawn_local(async move {
                if let Err(e) =
                    TerminalExecutor::send_special_key_on_handle(&wh, &raw_owned)
                {
                    eprintln!("Error sending special key: {e}");
                    let _ = tv.append_output(&format!("\nError sending special key: {e}\n"));
                }
            }) {
                eprintln!("Error spawning send_special_key task: {e}");
            }
        })?;

        // ── on_input_accepted: forward LineEdit Enter to on_send_command ─────
        let terminal_view_for_input = terminal_view.clone();
        terminal_view.on_input_accepted(move || {
            if let Ok(command) = terminal_view_for_input.get_current_command() {
                if !command.is_empty() {
                    terminal_view_for_input
                        .component
                        .invoke_send_command(command.into());
                    terminal_view_for_input.component.set_current_command("".into());
                }
            }
        })?;

        // ── on_close: DELETE the terminal ─────────────────────────────────────
        let terminal_name_clone = terminal.name.clone();
        let jupyter_url_clone = jupyter_url.clone();
        let jupyter_token_clone = jupyter_token.clone();

        terminal_view.on_close(move || {
            let t_name = terminal_name_clone.clone();
            let url = jupyter_url_clone.clone();
            let token = jupyter_token_clone.clone();

            if let Err(e) = slint::spawn_local(async move {
                let client = surf::client();
                let terminate_url = format!("{url}/api/terminals/{t_name}?token={token}");
                if let Err(e) = client.delete(terminate_url).await {
                    eprintln!("Error terminating terminal: {e}");
                }
            }) {
                eprintln!("Error spawning terminal termination task: {e}");
            }
        })?;

        terminal_view.show()?;

        // Execute initial command if provided
        if let Some(command) = initial_command {
            terminal_view.set_current_command(&command)?;
            if !command.is_empty() {
                let wh2 = write_handle.clone();
                if let Err(e) = slint::spawn_local(async move {
                    if let Err(e) = TerminalExecutor::send_command_on_handle(&wh2, &command) {
                        eprintln!("Error sending initial command: {e}");
                    }
                }) {
                    eprintln!("Error spawning initial command execution: {e}");
                }
            }
        }
    }

    if let Some(ui) = ui_handle.upgrade() {
        ui.set_status_text(
            format!(
                "Connected to {}. Popup window opened.",
                if is_kernel { "kernel" } else { "terminal" }
            )
            .into(),
        );
    }

    Ok(())
}

fn update_notebook_list(ui: &MainWindow, notebooks: &[Notebook]) {
    let mut notebook_data = Vec::new();

    for (i, notebook) in notebooks.iter().enumerate() {
        notebook_data.push(NotebookItem {
            id: (i + 1).to_string().into(),
            cluster_id: notebook.cluster_id.clone().into(),
            project: notebook.project.clone().into(),
            name: notebook.name.clone().into(),
            handle: notebook.handle.clone().into(),
            state: notebook.state.clone().into(),
            vm_type: notebook.vm_type.clone().into(),
        });
    }

    ui.set_notebooks(slint::ModelRc::new(slint::VecModel::from(notebook_data)));
}

fn update_machine_types(ui: &MainWindow, machine_types: &[LabelAvailability]) {
    let mut machine_type_data = Vec::new();

    for (i, mt) in machine_types.iter().enumerate() {
        machine_type_data.push(MachineTypeItem {
            id: (i + 1).to_string().into(),
            label: mt.label.clone().into(),
            available: mt.is_available,
        });
    }

    ui.set_machine_types(slint::ModelRc::new(slint::VecModel::from(
        machine_type_data,
    )));
}
