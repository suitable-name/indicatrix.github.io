# paperspace-ui

A new Rust application generated from the custom template.
